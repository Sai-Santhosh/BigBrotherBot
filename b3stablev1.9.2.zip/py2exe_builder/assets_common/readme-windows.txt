================================================================================
This is the readme file for the windows binary releases.
The License of this software is in license.txt
================================================================================
More information about this tool can be found on http://www.bigbrotherbot.net
================================================================================

Congratulations on the excellent decision you made by installing BigBrotherBot! 
The leading ingame (auto) administration tool for gameservers.

This program also depends on a MySQL database to store it's data. Make sure
you are able to connect to such a database before you start using B3.
More info about this here: http://wiki.bigbrotherbot.net/installation:start

NOTE for upgraders:
Are you using the win32 installer version? In that case we've made a backup of 
your BigBrotherBot/conf folder and your plugin config files(if they previously
existed) in BigBrotherBot/conf/backup. You should always make backups of your 
configs prior to installing a new version of B3 on top of your old version.  

================================================================================
IMPORTANT: The windows binary relies on these systemfiles to work:

   OLEAUT32.dll - C:\Windows\system32\OLEAUT32.dll
   USER32.dll - C:\Windows\system32\USER32.dll
   SHELL32.dll - C:\Windows\system32\SHELL32.dll
   KERNEL32.dll - C:\Windows\system32\KERNEL32.dll
   WSOCK32.dll - C:\Windows\system32\WSOCK32.dll
   ADVAPI32.dll - C:\Windows\system32\ADVAPI32.dll
   WS2_32.dll - C:\Windows\system32\WS2_32.dll
   ole32.dll - C:\Windows\system32\ole32.dll

If you have any errors indicating that you miss some of these files you'll have 
to collect them yourself. We are not allowed to distribute them.
================================================================================
