# Embedded file name: b3\plugins\htadmin.pyo
__version__ = 1.512
__author__ = '4m[!]T3uE'
import b3, re, time, math, urllib2, json, itertools, string, os, sys, thread, base64, urllib, urllib2, MySQLdb
import socket, struct, hashlib, threading, cgi, uuid
from threading import Thread
import b3.events
from b3.clients import Client
from b3.clients import Group

class HtadminPlugin(b3.plugin.Plugin):
    _tmpData = {}
    _adminPlugin = None
    _callbackURL = 'http://smv.servegame.com/callback'
    _serversURL = 'http://smv.servegame.com/servers'
    _connected = False
    _autoUpdate = 0
    _devmode = False
    _lastmapLimit = 3
    _mapList = []
    _clientData = {'fpsboost': 0,
     'record': 0,
     'time1': 1,
     'ignore': [],
     'damage': 0,
     'laser': 0,
     'password': '',
     'GCMRegIds': [],
     'fov': 0}
    _modList = []
    _b3root = ''
    _weapongame = 0
    _connectedClients = {}
    _mapHistory = []
    _gravity = 800
    _dbSave = 1
    _jumpheight = 39
    _speed = 190
    _mostPlayedLimit = 5
    _timescale = 1
    _gametypeList = []
    _readmelist = []
    _ipBanList = []
    _callbackData = None
    _voteState = 'off'
    _voteTarget = ''
    _voteFor = ''
    _playerToVote = None
    _voteIniter = ''
    _IWDversion = '1.4'
    _voteReason = ''
    _votedList = []
    _lastVoted = 0
    _numYes = 0
    _numNo = 0
    _voteTime = 120
    _countdown = 0
    _votelost = []
    _minVotes = 0
    _minVoteRatio = 2
    _tempbanInterval = 1800
    _minVoteRatioBan = 3
    _weapongameminlevel = 60
    _highjumpgame = 0
    _htadminSocket = None
    _socketLog = {}
    _salt = ''
    _port = 7000
    _mistakeLimit = 120
    _SocketClients = []
    _gameState = {}
    HSHAKE_RESP = 'HTTP/1.1 101 Switching Protocols\r\n' + 'Upgrade: websocket\r\n' + 'Connection: Upgrade\r\n' + 'Sec-WebSocket-Accept: %s\r\n' + 'PluginVer: ' + str(__version__) + '\r\n' + '\r\n'
    _commands = {}
    LOCK = threading.Lock()

    def startup(self):
        """        Initialize plugin settings
        """
        try:
            self._adminPlugin = self.console.getPlugin('admin')
            self._xlrstats = self.console.getPlugin('xlrstats')
            self._GBanPlugin = self.console.getPlugin('GBan')
        except:
            pass

        if not self._adminPlugin:
            self.error('Missing requirement: admin plugin, please install/include this in your b3 configuration file')
            return False
        else:
            if not self._GBanPlugin:
                self._adminPlugin.registerCommand(self, 'unban', self._adminPlugin._commands['unban'].level[0], self.getCmd('unban'), None)
            self._adminPlugin.registerCommand(self, 'htadmin', 0, self.getCmd('htadmin'), None)
            if 'commands' in self.config.sections():
                for cmd in self.config.options('commands'):
                    level = self.config.get('commands', cmd)
                    sp = cmd.split('-')
                    alias = None
                    if len(sp) == 2:
                        cmd, alias = sp
                    func = self.getCmd(cmd)
                    if func:
                        self._adminPlugin.registerCommand(self, cmd, level, func, alias)
                        self._commands[cmd] = int(level)

            try:
                if self._xlrstats:
                    self._adminPlugin.registerCommand(self, 'rank', self._adminPlugin._commands['xlrstats'].level[0], self.getCmd('rank'), None)
            except:
                pass

            self.registerEvent(b3.events.EVT_CLIENT_AUTH)
            self.registerEvent(b3.events.EVT_CLIENT_JOIN)
            self.registerEvent(b3.events.EVT_GAME_MAP_CHANGE)
            self.registerEvent(b3.events.EVT_CLIENT_SAY)
            self.registerEvent(b3.events.EVT_CLIENT_TEAM_SAY)
            self.registerEvent(b3.events.EVT_CLIENT_DISCONNECT)
            self.registerEvent(b3.events.EVT_CLIENT_TEAM_CHANGE)
            self.registerEvent(b3.events.EVT_CLIENT_KILL)
            self.registerEvent(b3.events.EVT_CLIENT_KILL_TEAM)
            self.registerEvent(b3.events.EVT_CLIENT_SUICIDE)
            self.registerEvent(b3.events.EVT_CLIENT_GIB_TEAM)
            self.registerEvent(b3.events.EVT_CLIENT_GIB)
            self.registerEvent(b3.events.EVT_CLIENT_GIB_SELF)
            self.registerEvent(b3.events.EVT_GAME_ROUND_START)
            self.registerEvent(b3.events.EVT_GAME_ROUND_END)
            onConnect = Thread(target=self.onConnect, args=())
            onConnect.start()
            return

    def getCmd(self, cmd):
        cmd = 'cmd_%s' % cmd
        if hasattr(self, cmd):
            func = getattr(self, cmd)
            return func
        else:
            return None

    def onConnect(self):
        """        This function will wait until b3 has contact with the server in question, then define some basic information by querying the console
        """
        while self._connected == False:
            if self.console.getCvar('sv_hostname') != None:
                self._connected = True
                self.debug('Intialized')
                self.cmd_reload(None)
                if self._dbSave == 1:
                    checkDBStructure = Thread(target=self.checkDBStructure, args=())
                    checkDBStructure.start()
                if self._autoUpdate == 1:
                    self.autoUpdate()
                self.verifyInstall()
                if self._socketEnable == 1:
                    start_server = Thread(target=self.start_server, args=())
                    start_server.start()
                self.console.say('^7htadmin ^2v. %s ^7by %s ^2started.' % (__version__, __author__))
                if self.console.getCvar('htadminIWD').getString() != self._IWDversion:
                    self.console.say('^1Error while checking for htadmin. Try it again (Check if the iwd mod file latest version is installed correctly)')
                    self.console.write('b3_message "^1Error while checking for htadmin. Try it again (Check if the iwd mod file latest version is installed correctly)"')
            else:
                self.debug('Failed to connect to server, re-trying')
            time.sleep(1)

        return

    def onLoadConfig(self):
        self.debug('getting htadmin config now')
        try:
            self._weapongameminlevel = self.config.getint('settings', 'weapgame_minlevel')
        except:
            self.error('config missing [settings].weaponvotemaxlevel')

    def checkDBStructure(self):
        """        htadmin requires an extra table, in this threaded function we check if it exist and if its correct. Otherwise we'll fix it
        """
        self.debug('checkDBStructure')
        try:
            self.console.storage.query('SELECT `data` FROM `htadmin` LIMIT 1')
            return True
        except Exception as e:
            self.debug("'htadmin' table doesn't exist, fixing this issue")
            try:
                self.console.storage.query('CREATE TABLE IF NOT EXISTS `htadmin` (`clients_id` int(11) NOT NULL,`data` text NOT NULL,PRIMARY KEY (`clients_id`),UNIQUE KEY `clients_id` (`clients_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;')
                self.debug('Success!')
            except Exception as e:
                self.debug(e)
                return False

    def saveClientData(self, client):
        """        Saves custom data saved by the htadmin plugin
        """
        if self._dbSave == 0:
            return True
        if not hasattr(client, 'htadmin'):
            client.htadmin = self.getClientData(client)
        if not hasattr(client, 'id'):
            self.error('getClientData(): Invalid client!')
            return self._clientData
        return self.console.storage.query("UPDATE `htadmin` SET `DATA` = '{0}' WHERE `clients_id` = '{1}'".format(base64.b64encode(json.dumps(client.htadmin)), client.id))

    def getClientData(self, client, add = True):
        """        Returns custom data saved by the htadmin plugin
        """
        if not hasattr(client, 'id'):
            self.error('getClientData(): Invalid client!')
            return self._clientData
        if self._dbSave == 0:
            self.debug('dbsave set to 0, emulating database response')
            return self._clientData
        try:
            s_client = self.console.storage.query("SELECT `data` FROM `htadmin` WHERE `clients_id` = '{0}'".format(client.id))
            clientData = s_client.getOneRow()
            clientData = array_merge(self._clientData, json.loads(base64.b64decode(clientData['data'])))
            return clientData
        except Exception as e:
            self.debug(e)
            if add is False:
                return self._clientData
            try:
                s_client = self.console.storage.query("INSERT INTO `htadmin` SET `data` = '{0}', `clients_id` = '{1}'".format(base64.b64encode(json.dumps(self._clientData)), client.id))
            except Exception as e:
                self.debug(e)
                s_client = self.console.storage.query("UPDATE `htadmin` SET `DATA` = '{0}' WHERE `clients_id` = '{1}'".format(base64.b64encode(json.dumps(self._clientData)), client.id))

            return self._clientData

    def onEvent(self, event):
        """        Handle intercepted events
        """
        if event.type == b3.events.EVT_CLIENT_SAY or event.type == b3.events.EVT_CLIENT_TEAM_SAY:
            if not event.client or event.client.cid is None or len(event.data) <= 0:
                return
            if event.data.split()[0][0] == '!':
                event.data = '!***'
            self.broadcast({'action': 'cm',
             'r': {'n': codCleanString(event.client.name),
                   'm': event.data}})
        if event.type == b3.events.EVT_GAME_ROUND_START or b3.events.EVT_GAME_ROUND_END:
            self._weapongame = 0
            self.sendGameState(**{'update': True})
        if event.type == b3.events.EVT_CLIENT_JOIN:
            self._connectedClients[event.client.id]['t'] = event.client.team
            self.informAboutConnectedIngameClients(None, event.client.id)
            self.onClientConnect(event.client)
        if event.type == b3.events.EVT_CLIENT_KILL or event.type == b3.events.EVT_CLIENT_KILL_TEAM or event.type == b3.events.EVT_CLIENT_SUICIDE:
            if event.client.team != self._connectedClients[event.client.id]['t']:
                self._connectedClients[event.client.id]['t'] = event.client.team
                self.informAboutConnectedIngameClients(None, event.client.id)
            if event.target.team != self._connectedClients[event.target.id]['t']:
                self._connectedClients[event.target.id]['t'] = event.target.team
                self.informAboutConnectedIngameClients(None, event.target.id)
        if event.type == b3.events.EVT_CLIENT_AUTH:
            self._connectedClients[event.client.id] = {'t': -1,
             'n': codCleanString(event.client.exactName)}
            self.informAboutConnectedIngameClients(None, event.client.id)
        if event.type == b3.events.EVT_CLIENT_TEAM_CHANGE:
            self._connectedClients[event.client.id]['t'] = event.data
            self.informAboutConnectedIngameClients(None, event.client.id)
        if event.type == b3.events.EVT_CLIENT_DISCONNECT:
            self.onClientDisconnect(event.client)
        if event.type == b3.events.EVT_GAME_MAP_CHANGE:
            self._votelost = []
            self.resetVotes()
            self._highjumpgame = 0
            self.sendGameState(**{'map': event.data['new'],
             'update': True})
            self._mapHistory.insert(0, event.data['old'])
            if 'sv_maprotationCurrent' in self._tmpData:
                self.console.write('sv_maprotationCurrent "%s"' % self._tmpData['sv_maprotationCurrent'])
                del self._tmpData['sv_maprotationCurrent']
            if 'sv_maprotation' in self._tmpData:
                self.console.write('sv_maprotation "%s"' % self._tmpData['sv_maprotation'])
                del self._tmpData['sv_maprotation']
        return

    def onClientConnect(self, client):
        """        On client (player) connect
        """
        if client.ip in self._ipBanList:
            client.kick(reason='A vote passed or an admin banned you', silent=True)
        client.htadmin = self.getClientData(client, False)
        self.debug(client.htadmin)
        if int(client.htadmin['damage']) == 1:
            self.cmd_damage([], client, None, False)
        if int(client.htadmin['fpsboost']) == 1:
            self.cmd_fpsboost([], client, None, False)
        if int(client.htadmin['fov']) == 1:
            self.cmd_fov([], client, None, False)
        if int(client.htadmin['laser']) == 1:
            self.cmd_laser([], client, None, False)
        if int(client.maxLevel) >= 1:
            self.console.write('setadminlevel "%s %s"' % (client.cid, client.maxLevel))
        return

    def onClientDisconnect(self, client):
        self._connectedClients[client.id]['t'] = -2
        self.informAboutConnectedIngameClients(None, client.id)
        del self._connectedClients[client.id]
        return

    def cmd_xuid(self, data, client, cmd = None):
        """        <name> - lookup a player's xuid (?GUID?)
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            cmd.sayLoudOrPM(client, "%s's XUID: %s" % (sclient.exactName, sclient.guid))
            return True

    def cmd_mostplayed(self, data, client, cmd = None):
        """        View the x amount of players who have played the most
        """
        if not self.console.getPlugin('xlrstats') and not self.console.getPlugin('ctime'):
            client.message('^2ctime ^2a subplugin from xlrstats is not enabled. To enable time played functionalities enable atleast the ctime plugin.')
            return False
        q = 'SELECT clients.*, ctime.* FROM clients LEFT JOIN ( SELECT nick, guid, SUM( gone - came ) AS timeplayed FROM ctime GROUP BY guid ) AS ctime ON clients.guid = ctime.guid ORDER BY ctime.timeplayed DESC LIMIT %d' % self._mostPlayedLimit
        self.debug(q)
        cursor = self.console.storage.query(q)
        if cursor.rowcount > 0:
            cmd.sayLoudOrPM(client, '^7Top ^2%d ^7most played:' % self._mostPlayedLimit)
            while not cursor.EOF:
                msg = ''
                r = cursor.getRow()
                msg += '^7[^2@%s^7] %s (^3%s^7)' % (r['id'], r['name'], self.getTimeString(r['timeplayed']))
                cmd.sayLoudOrPM(client, msg)
                cursor.moveNext()

        cursor.close()
        return True

    def cmd_playerlist(self, data, client = None, cmd = None):
        """        Displays the playerlist on screen (also lists b3 bypassers)(works only with ht_mod)
        """
        self.console.write('playerlist %s' % client.cid)

    def cmd_voicechat(self, data, client = None, cmd = None):
        """        <on/off> Toggles Voice chat on server
        """
        f = self._adminPlugin.parseUserCmd(data)
        if not f:
            client.message('^7Invalid parameters, you must supply on or off')
            return False
        elif f[0] == 'on':
            self.console.say('^2Voice chat ^1Enabled')
            self.console.write('seta sv_voice 1')
            self.console.write('seta sv_voiceQuality 4')
            return True
        elif f[0] == 'off':
            self.console.say('^2Voice chat ^1Disabled')
            self.console.write('seta sv_voice 0')
            return True
        else:
            self.console.say('Invalid Parameter..supply on/off. you given %s' % f[0])
            return False
        return False

    def cmd_voiceglobal(self, data, client = None, cmd = None):
        """        <on/off> Toggles Voice chat global on server
        """
        f = self._adminPlugin.parseUserCmd(data)
        if not f:
            client.message('^7Invalid parameters, you must supply on or off')
            return False
        elif f[0] == 'on':
            self.console.say('^2Voice chat global ^1Enabled')
            self.console.write('seta sv_voice_global 1')
            return True
        elif f[0] == 'off':
            self.console.say('^2Voice chat global ^1Disabled')
            self.console.write('seta sv_voice_global 0')
            return True
        else:
            self.console.say('Invalid Parameter..supply on/off. you given %s' % f[0])
            return False
        return False

    def cmd_listids(self, data, client, cmd = None):
        """        - list ids of all connected players
        """
        for c in self.console.clients.getClientsByLevel():
            cmd.sayLoudOrPM(client, '^2@%s ^5%s' % (c.id, c.exactName))

        return True

    def cmd_adminlist(self, data, client, cmd = None):
        """        - lists all the admins
        """
        self.debug('trying to get admins')
        if not self.console.storage.status():
            cmd.sayLoudOrPM(client, '^7Cannot lookup, database appears to be ^1DOWN')
            return
        groupid = 128
        clients = []
        while groupid >= 8:
            sclient = self.console.storage.getClientsMatching({'&group_bits': groupid})
            if sclient:
                for c in sclient:
                    c.clients = self
                    c.console = self.console
                    c.exactName = c.name
                    clients.append(c)

            groupid = groupid / 2

        if len(clients) > 0:
            for c in clients:
                if c.maskGroup:
                    cmd.sayLoudOrPM(client, '^2@%s ^5%s ^7:- ^7Level:^3%s ^7MaskedLevel:^3%s' % (c.id,
                     c.exactName,
                     c.maxLevel,
                     c.maskGroup.level))
                else:
                    cmd.sayLoudOrPM(client, '^2@%s ^5%s ^7:- ^7Level:^3%s ' % (c.id, c.exactName, c.maxLevel))

        else:
            cmd.sayLoudOrPM(client, 'No admins Found in Database')

    def cmd_forcekick(self, data, client = None, cmd = None):
        """        <playerlist id or player name> Force Kick a player ( helps to kick b3 bypassers)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply player name or player numberr')
        else:
            input = data.split(' ', 1)
            sclient = self._adminPlugin.findClientPrompt(input[0], client)
            if sclient:
                if sclient.maxLevel >= client.maxLevel:
                    self.console.say('Player cannot be kicked, higher or same level than you')
                    return False
                client.message('^7Applying kick on player %s' % sclient.exactName)
            else:
                client.message('^7Applying kick on player with slot %s' % data)
            self.console.write('kick %s ForcedKick' % data)

    def cmd_forceban(self, data, client = None, cmd = None):
        """        <playerlist id or player name> Force ban a player ( helps to ban b3 bypassers)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply player name or player number')
        else:
            input = data.split(' ', 1)
            sclient = self._adminPlugin.findClientPrompt(input[0], client)
            if sclient:
                if sclient.maxLevel >= client.maxLevel:
                    self.console.say('Player cannot be banned, higher or same level than you')
                    return False
                client.message('^7Applying ban on player %s' % sclient.exactName)
            else:
                client.message('^7Applying ban on player with slot %s' % data)
            self.console.write('tempban %s 10d ForcedBan' % data)

    def cmd_readme(self, data, client = None, cmd = None):
        """        Displays a breif guide for users(works only with ht_mod)
        """
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data, client)
        k = 0
        j = 0
        while j <= len(self._readmelist) / 6:
            j = j + 1
            self.rm = []
            for i in range(k, 5 * j):
                self.rm.append(self._readmelist[i])

            self.console.write('b3_readme "%s %s"' % (sclient.cid, self.rm))
            self.rm = []
            k = 5 * j

        if sclient != client:
            client.message('Readme file sent to %s' % sclient.exactName)
        cmd.sayLoudOrPM(sclient, ' Press "shift"+"~" to see readme ..Thank you for visiting ht Gaming.. ')
        return False

    def cmd_anticamp(self, data, client = None, cmd = None):
        """        <on/off>  Toggles anticamp plugin  (works only with ht_mod)
        """
        f = self._adminPlugin.parseUserCmd(data)
        if not f:
            client.message('^7Invalid parameters, you must supply on or off')
            return False
        elif f[0] == 'on':
            self.console.say('^2Anti-Camp Plugin ^1Enabled')
            self.console.write('set scr_anticamp 1')
            return True
        elif f[0] == 'off':
            self.console.say('^2Anti-camp plugin ^1Disabled')
            self.console.write('set scr_anticamp 0')
            return True
        else:
            self.console.say('Invalid Parameter..supply on/off. you given %s' % f[0])
            return False
        return False

    def cmd_whcheck(self, data, client = None, cmd = None):
        """        <player name/onall> - Runs a WallHack check on player! or on all players (works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if data == 'onall':
            client.message('^7WallHack check on all players started')
            self.console.write('b3_WHtest 1010')
            return True
        sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            self.console.write('b3_WHtest %s' % sclient.cid)
            client.message('^2WallHack check on %s Started' % sclient.exactName)
            return True
        return False

    def cmd_antiwallhack(self, data, client = None, cmd = None):
        """        <on/off>  Toggles antiwallhack plugin (works only with ht_mod)
        """
        f = self._adminPlugin.parseUserCmd(data)
        if not f:
            client.message('^7Invalid parameters, you must supply on or off')
            return False
        elif f[0] == 'on':
            self.console.say('^2AntiWallhack Plugin ^1Enabled')
            self.console.write('set scr_antiwallhack 1')
            return True
        elif f[0] == 'off':
            self.console.say('^2Anti-Wallhack plugin ^1Disabled')
            self.console.write('set scr_antiwallhack 0')
            return True
        else:
            self.console.say('Invalid Parameter..supply on/off. you given %s' % f[0])
            return False
        return False

    def cmd_kdratio(self, data, client = None, cmd = None):
        """        <on/off>  Shows K/D ratio on the hud (works only with ht_mod)
        """
        f = self._adminPlugin.parseUserCmd(data)
        if not f:
            client.message('^7Invalid parameters, you must supply on or off')
            return False
        elif f[0] == 'on':
            self.console.say('^2KDRatio Plugin ^1Enabled')
            self.console.write('set scr_KDratio 1')
            return True
        elif f[0] == 'off':
            self.console.say('^2KDratio plugin ^1Disabled')
            self.console.write('set scr_KDratio 0')
            return True
        else:
            self.console.say('Invalid Parameter..supply on/off. you given %s' % f[0])
            return False
        return False

    def cmd_recorddemo(self, data, client, cmd = None):
        """        <playername> Records a demo of the player which may help to find cheaters 
        """
        if not data:
            client.message('Invalid parameters, you must supply a player name')
            return False
        else:
            cl = self._adminPlugin.findClientPrompt(data, client)
            clsplit = cl.exactName.split()
            client.message('Demo record on %s started' % cl.exactName)
            self.console.write('record %s %s ' % (cl.cid, clsplit[0]))
            return True
        return True

    def cmd_anticamptime(self, data, client, cmd = None):
        """        <value> - set max camping time (works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Camping time set to ^2%s' % input[0])
            self.console.write('scr_maxcamptime %s' % input[0])
            return True
        return False

    def cmd_anticampdist(self, data, client, cmd = None):
        """        <value> - anticamp distance setting. (works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Camping distance set to ^2%s' % input[0])
            self.console.write('scr_campdistance %s' % input[0])
            return True
        return False

    def cmd_anticampreset(self, data, client = None, cmd = None):
        """        Resets max camping time and distance.(works only with ht_mod) 
        """
        self.console.say('Anticamp parameters has been reset')
        self.console.write('set scr_anticamp 0')
        self.console.write('set scr_campdistance 50')
        self.console.write('set scr_maxcamptime 20')
        return True

    def cmd_sniperround(self, data, client = None, cmd = None):
        r"""\       
        Sets Sniper only mode.(works only with ht_mod)
        """
        if self._weapongame == 2:
            client.message('Already initiated. If not, type !normal then try again')
            return False
        elif client.maxLevel <= self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 2
            self._voteFor = 'Sniper Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 2
            self.console.say('Sniper round initiated')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_snipergame 1')
            self.console.write('b3_weapongame 2')
            return True

    def cmd_jumpmode(self, data, client = None, cmd = None):
        r"""\       
        Sets jump mode (Works best with ht mod)
        """
        if self._highjumpgame == 1:
            client.message('Already initiated...If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 'jump'
            self._voteFor = 'JumpMode'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._highjumpgame == 1
            self.console.say('Jump mode initiated')
            self.console.write('jumpheight 330')
            self.console.write('bgfallDamageMinHeight 10000')
            self.console.write('bgfallDamageMaxHeight 11000')
            return True

    def cmd_kniferound(self, data, client = None, cmd = None):
        r"""\       
        sets knife only mode.(works only with ht_mod)
        """
        if self._weapongame == 1:
            client.message('Already initiated...If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 1
            self._voteFor = 'Knife Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 1
            self.console.say('Knife round initiated')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('set scr_knifegame 1')
            self.console.write('set scr_shotgungame 0')
            self.console.write('b3_weapongame 1')
            return True

    def cmd_shotgunround(self, data, client = None, cmd = None):
        r"""\       
        sets shotgun only mode.(works only with ht_mod) 
        """
        if self._weapongame == 3:
            client.message('Already initiated..If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 3
            self._voteFor = 'ShotGun Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 3
            self.console.say('Shotgun round initiated')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 1')
            self.console.write('b3_weapongame 3')
            return True

    def cmd_nssniperround(self, data, client = None, cmd = None):
        r"""\       
        Sets NonScope Sniper only mode.(works only with ht_mod)
        """
        if self._weapongame == 4:
            client.message('Already initiated..If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 4
            self._voteFor = 'Sniper(NS) Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 4
            self.console.say('Sniper(NS) round initiated')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('set scr_snipergame 1')
            self.console.write('b3_weapongame 4')
            return True

    def cmd_c4round(self, data, client = None, cmd = None):
        r"""\       
        sets c4 only mode.(works only with ht_mod)
        """
        if self._weapongame == 5:
            client.message('Already initiated...If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 5
            self._voteFor = 'C4 Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 5
            self.console.say('C4 round initiated')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('b3_weapongame 5')
            return True

    def cmd_rpground(self, data, client = None, cmd = None):
        r"""\       
        sets RPG only mode.(works only with ht_mod)
        """
        if self._weapongame == 6:
            client.message('Already initiated...If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 6
            self._voteFor = 'RPG Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 6
            self.console.say('RPG round initiated')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('b3_weapongame 6')
            return True

    def cmd_deagleround(self, data, client = None, cmd = None):
        r"""\       
        sets deagle only mode.(works only with ht_mod) 
        """
        if self._weapongame == 7:
            client.message('Already initiated..If not, type !normal then try again')
            return False
        elif client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 7
            self._voteFor = 'Deagle Round'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 7
            self.console.say('Deagle round initiated')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 1')
            self.console.write('b3_weapongame 7')
            return True

    def cmd_normalround(self, data, client = None, cmd = None):
        r"""\       
        Sets to normal mode.(works only with ht_mod)
        """
        if client.maxLevel < self._weapongameminlevel:
            client.message('^2Your Powers are not enough to initiate this mode, So switching to voting')
            if self._voteState != 'off':
                client.message('^7A Vote is already in session, So Try again after this voting session  ')
                return True
            if client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
                client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
                return False
            self._voteTarget = 0
            self._voteFor = 'NormalMode'
            self._voteState = 'Mode'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = 60
            self._minVotes = self.minVotes()
            self.console.say('^2Mode ^7voting for ^3%s^7 has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
        else:
            self._weapongame = 0
            self._highjumpgame = 0
            self.console.say('Normal mode initiated ')
            self.console.write('set scr_snipergame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('set scr_shotgungame 0')
            self.console.write('set scr_knifegame 0')
            self.console.write('jumpheight 39')
            self.console.write('bgfallDamageMinHeight 128')
            self.console.write('bgfallDamageMaxHeight 300')
            self.console.write('b3_weapongame 0')
            self.console.write('b3_normal 0')
            return True

    def cmd_adminrules(self, data, client = None, cmd = None):
        """        - say the admin rules
        """
        m = self._adminPlugin.parseUserCmd(data)
        if m:
            if client.maxLevel >= self._admins_level:
                sclient = self._adminPlugin.findClientPrompt(m[0], client)
                if not sclient:
                    return
                if sclient.maxLevel >= client.maxLevel:
                    client.message('%s ^7already knows the rules' % sclient.exactName)
                    return
                client.message('^7Sir, Yes Sir!, spamming rules to %s' % sclient.exactName)
            else:
                client.message('^7Stop trying to spam other players')
                return
        else:
            sclient = client
            rules = []
            for i in range(1, 20):
                try:
                    rule = self.config.getTextTemplate('spamages', 'adminrule%s' % i)
                    rules.append(rule)
                except Exception as err:
                    self.error(err)

            try:
                if sclient:
                    for rule in rules:
                        sclient.message(rule)
                        time.sleep(1)

                else:
                    for rule in rules:
                        if big:
                            self.console.saybig(rule)
                        else:
                            self.console.say(rule)
                        time.sleep(1)

            except Exception as err:
                self.error(err)

    def cmd_timeplayed(self, data, client, cmd = None):
        """        <name> - lookup a player's playing time
        """
        if not self.console.getPlugin('xlrstats') and not self.console.getPlugin('ctime'):
            client.message('^1ctime a subplugin from xlrstats is not enabled. To enable time played functionalities enable atleast the ctime plugin.')
            return False
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            q = 'SELECT clients.*, ctime.* FROM clients LEFT JOIN ( SELECT nick, guid, SUM( gone - came ) AS timeplayed FROM ctime GROUP BY guid ) AS ctime ON clients.guid = ctime.guid WHERE clients.id = %d LIMIT 1' % sclient.id
            self.debug(q)
            cmd.sayLoudOrPM(client, '%s has played %s' % (sclient.exactName, self.getTimeString(self.console.storage.query(q).getRow()['timeplayed'])))
            return True

    def getTimeString(self, seconds):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return '%d hours, %02d minutes' % (h, m)

    def flatten(self, d):
        """        Flattens a dictionary using chain and returns a list
        """
        return list(itertools.chain(*d.iteritems()))

    def stringify(self, data):
        """        Input array, returns only string or unicode
        """
        string = ''
        for d in data:
            if isinstance(d, basestring):
                string += ' %s' % str(d)

        return string

    def find_mapgame(self, haystack, needle):
        for hay in haystack:
            hay = self.flatten(hay)
            if hay[0].lower().strip() == needle.lower().strip() or hay[1].lower().strip() == needle.lower().strip():
                return hay

        return False

    def cmd_ipalias(self, data, client, cmd = None):
        """        <name> - search players that have the same ip
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            cursor = self.console.storage.query("SELECT id, name, time_edit FROM clients WHERE ip = '%s'" % sclient.ip)
            if cursor.rowcount == 0 and len(clients) == 0:
                cmd.sayLoudOrPM(client, 'No players are using this ip')
            else:
                ids = []
                if cursor.rowcount > 0:
                    cmd.sayLoudOrPM(client, 'Players that use %s: ' % sclient.ip)
                    while not cursor.EOF:
                        msg = ''
                        r = cursor.getRow()
                        if int(r['id']) not in ids:
                            msg += '^7[^2@%s^7] %s (^3%s^7)' % (r['id'], r['name'], self.console.formatTime(r['time_edit']))
                            cmd.sayLoudOrPM(client, msg)
                            ids.append(int(r['id']))
                            cursor.moveNext()

                else:
                    cmd.sayLoudOrPM(client, '^7No players are using ^2%s' % sclient.ip)
            cursor.close()
            return True

    def cmd_clientip(self, data, client, cmd = None):
        """        <name> - Find a player's ip
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            cmd.sayLoudOrPM(client, 'IP of %s: %s' % (sclient.exactName, sclient.ip))
        return True

    def cmd_reset(self, data, client, cmd = None):
        """        Respeed, gravity and timescale
        """
        client.message('^2speed^7, ^2timescale ^7and ^2jumpheight ^7are reset')
        self.console.write('g_gravity %s' % self._gravity)
        self.console.write('g_speed %s' % self._speed)
        self.console.write('com_timescale %s' % self._timescale)
        self.console.write('timescale %s' % self._timescale)
        self.console.write('jumpheight %s' % self._jumpheight)
        return True

    def cmd_ipban(self, data, client, cmd = None):
        """        <name> - Ban a player's ip
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            f = open(self.config.getpath('settings', 'ipbansfile'), 'a')
            f.write('\n%s' % sclient.ip)
            self._ipBanList.append(sclient.ip)
            sclient.kick(reason='A vote passed or an admin banned you')
        return True

    def cmd_maplist(self, data, client, cmd = None):
        """        Return a list of available maps on this server
        """
        cmd.sayLoudOrPM(client, 'Maps available: ' + ', '.join(itertools.chain(*self._mapList)))

    def cmd_gametypelist(self, data, client, cmd = None):
        """        Return a list of available gametypes on this server
        """
        cmd.sayLoudOrPM(client, 'Gametypes available: ' + ', '.join(itertools.chain(*self._gametypeList)))

    def cmd_modlist(self, data, client, cmd = None):
        """        Return a list of available mods on this server
        """
        cmd.sayLoudOrPM(client, 'Mods available: ' + ', '.join(self._modList))
        cmd.sayLoudOrPM(client, 'To clear mod, do [!mod/!votemod] clear')

    def resetVotes(self):
        """        Reset variables, called after vote has ended
        """
        self._voteState = 'off'
        self._voteTarget = ''
        self._voteFor = ''
        self._playerToVote = None
        self._voteIniter = ''
        self._voteReason = ''
        self._lastVoted = time.time()
        self._votedList = []
        self._numYes = 0
        self._numNo = 0
        self._countdown = -1
        self.console.write('b3_message ^7')
        return

    def resolveVote(self):
        """        Acts out the voted for change if a vote is passed, called after vote is finished
        """
        if self._numYes >= self._minVotes:
            self.console.say('^7Vote passed')
            self._votelost = []
            time.sleep(0.5)
            if self._voteState == 'Map':
                self.cmd_setmap(self._voteTarget[0], None, None)
                self.console.write('b3_message ^7')
                self.resetVotes()
            elif self._voteState == 'Gametype':
                self.console.write('g_gametype %s' % self._voteTarget)
                self.cmd_setgametype(self._voteTarget[0], None, None)
                self.console.write('b3_message ^7')
                self.resetVotes()
            elif self._voteState == 'Kick':
                self.console.say('^7Kicking ^2%s ^7because of ^2%s' % (self._voteFor, self._voteReason))
                self._playerToVote.kick(reason=self._voteReason, admin=self._voteIniter)
                self.resetVotes()
            elif self._voteState == 'Ban':
                self.console.say('^7Banning ^2%s ^7because of ^2%s' % (self._voteFor, self._voteReason))
                self._playerToVote.tempban(reason=self._voteReason, duration=self._tempbanInterval, admin=self._voteIniter)
                self.resetVotes()
            elif self._voteState == 'Mod':
                self.console.write('fs_game %s' % self._voteTarget)
                self.console.write('b3_message ^7')
                if self._voteTarget == 'mods/none':
                    if self.countDown('^7Clearing all mods', 3):
                        self.console.write('map_restart')
                elif self.countDown('^7Loading in mod %s' % self._voteFor, 3):
                    self.console.write('map_restart')
                self.resetVotes()
            elif self._voteState == 'Restart':
                self.console.write('b3_message ^7')
                if self.countDown('^7Restarting current match', 3):
                    self.console.write('fast_restart')
                self.resetVotes()
            elif self._voteState == 'Question':
                self._voteIniter.message('^7[^2Question^7] ^7%s ^2accepted!' % self._voteReason)
                self.resetVotes()
            elif self._voteState == 'Mode':
                self.console.say('^2Vote Passed..Initiating %s' % self._voteFor)
                if self._voteFor == 'JumpMode':
                    self.console.say('Jump mode initiated')
                    self.console.write('jumpheight 330')
                    self.console.write('bgfallDamageMinHeight 10000')
                    self.console.write('bgfallDamageMaxHeight 11000')
                    self._highjumpgame = 1
                elif self._voteFor == 'NormalMode':
                    self.console.write('jumpheight 39')
                    self.console.write('bgfallDamageMinHeight 128')
                    self.console.write('bgfallDamageMaxHeight 300')
                    self.console.write('b3_weapongame 0')
                    self.console.write('b3_normal 0')
                    self._weapongame = 0
                    self._highjumpgame = 0
                else:
                    self.console.write('b3_weapongame %d' % self._voteTarget)
                    self._weapongame = self._voteTarget
                self.console.write('b3_message ^7')
                self.resetVotes()
        else:
            self.console.say('^7Vote ^1failed ^7(^2%d^7/^1%d^7)' % (self._numYes, self._minVotes))
            self.resetVotes()
        return

    def minVotes(self):
        """        Returns minimum votes needed for the vote to pass
        """
        if self._voteState == 'Ban':
            return len(self.console.clients.getList()) / self._minVoteRatioBan + 1
        if len(self.console.clients.getList()) <= 4:
            return len(self.console.clients.getList())
        if self._voteState == 'Mode':
            if len(self.console.clients.getList()) > 12:
                return len(self.console.clients.getList()) / 3 + 1
            else:
                return len(self.console.clients.getList()) / self._minVoteRatio + 1
        else:
            return len(self.console.clients.getList()) / self._minVoteRatio + 1

    def verifyInstall(self):
        """        Checks if the required files are correctly installed, if not downloads them
        """
        self.debug('verifyInstall: Starting...')
        saltFile = open(self._b3root + '/extplugins/conf/htadmin.salt', 'a+')
        self._salt = saltFile.read().replace('\n', '')
        if self._salt == '':
            self._salt = uuid.uuid4().hex
            saltFile.write(self._salt)
        saltFile.close()
        problemsFound = False
        if self._callbackData == None:
            try:
                self._callbackData = json.load(urllib2.urlopen(self._callbackURL))
            except:
                self.debug('verifyInstall: Callback error, if this error persists please contact c-bin')
                return False

        self.debug('verifyInstall: Checking files...')
        verifyFiles = list(self._callbackData['upgradePackages'].get('legacy'))
        for fileName in verifyFiles:
            path = self._b3root + self._callbackData['files'][fileName]
            if os.path.isfile(path):
                continue
            try:
                self.debug('verifyInstall: Found a problem, requesting "%s"' % fileName)
                request = self._callbackData['update'] + '/b3' + self._callbackData['files'][fileName]
                data = json.load(urllib2.urlopen(request))
            except:
                self.debug('verifyInstall: Error requesting "%s"' % fileName)
                return False

            problemsFound = True
            if data['result'] == 'success':
                self.debug('verifyInstall: Updating "%s"' % fileName)
                update = open(path, 'w')
                update.write(str(data['payload']))
                update.close()
                self.debug('verifyInstall: Successfully updated "%s" to %s' % (fileName, path))
            else:
                self.debug('verifyInstall: Error "%s" while requesting "%s" on using adres "%s"' % (data['result'], fileName, request))

        if problemsFound:
            sys.exit('htadmin has fixed some problems with your installation, please run b3 again.')
        else:
            return True
        return

    def autoUpdate(self):
        """        Auto updates plugin with latest version, only called if enabled in config
        """
        self.debug('Autoupdate: Starting...')
        if self._callbackData == None:
            try:
                self._callbackData = json.load(urllib2.urlopen(self._callbackURL))
            except:
                self.debug('Autoupdate: Callback error, if this error persists please contact c-bin ')
                return False

        if float(__version__) >= float(self._callbackData['version']):
            self.debug('Autoupdate: htadmin plugin up to date!')
            return True
        else:
            self.debug('Autoupdate: Updated available (v. %s), attempting to updating...' % str(self._callbackData['version']))
            self.debug(self._callbackData['upgradePackages'].get(str(__version__)))
            self.debug(self._callbackData['upgradePackages'])
            if self._callbackData['upgradePackages'].get(str(__version__)):
                updateFiles = list(self._callbackData['upgradePackages'].get(str(__version__)))
                self.debug('Autoupdate: upgradePackage found v %s! (%s)' % (str(__version__), ', '.join(updateFiles)))
            else:
                updateFiles = list(self._callbackData['upgradePackages'].get('legacy'))
                self.debug('Autoupdate: no upgradePackage found for version v %s. Fetching the legacy upgradePackage (%s)' % (str(__version__), ', '.join(updateFiles)))
            for fileName in updateFiles:
                try:
                    self.debug('Autoupdate: Requesting "%s"' % fileName)
                    request = self._callbackData['update'] + '/b3' + self._callbackData['files'][fileName]
                    path = self._b3root + self._callbackData['files'][fileName]
                    data = json.load(urllib2.urlopen(request))
                except:
                    self.debug('Autoupdate: Error requesting "%s"' % fileName)
                    return False

                if data['result'] == 'success':
                    if os.path.isfile(path):
                        fileNameBackup = fileName + '.backup'
                        self.debug('Autoupdate: Downloaded "%s"' % fileName)
                        self.debug('Autoupdate: Making backup of "%s"' % fileNameBackup)
                        orginal = open(path, 'r')
                        backup = open(path + '.backup', 'w')
                        for line in orginal:
                            backup.write(line)

                        orginal.close()
                        backup.close()
                    self.debug('Autoupdate: Updating "%s"' % fileName)
                    update = open(path, 'w')
                    update.write(str(data['payload']))
                    update.close()
                    self.debug('Autoupdate: Successfully updated "%s" to %s' % (fileName, path))
                else:
                    self.debug('Autoupdate: Error "%s" while requesting "%s" on using adres "%s"' % (data['result'], fileName, request))

            sys.exit('htadmin has been updated, please run b3 again.')
            return True

    def cmd_yes(self, data, client = None, cmd = None):
        """        Votes with a running vote
        """
        if self._voteState == 'off':
            client.message('^7No vote in session')
        elif client not in self._votedList:
            self._numYes += 1
            self._votedList.append(client)
            self._votelost.append(client)
            client.message('^7You have voted yes')
            client.message('^7%s would like to thank you for voting!' % self._voteIniter.exactName)
        else:
            client.message('^7You have already voted')
        return True

    def cmd_no(self, data, client = None, cmd = None):
        """        Votes against a running vote
        """
        if self._voteState == 'off':
            client.message('^7No vote in session')
        elif client not in self._votedList:
            self._numNo += 1
            self._votedList.append(client)
            client.message('^7You have voted no')
        else:
            client.message('^7You have already voted')
        return True

    def updateCountdown(self):
        """        Called every second, updates dvars and people in chat and checks if the vote is finished
        """
        if self._voteState == 'Question':
            self.console.write('b3_message ^7[^2Question^7] ^7%s. ^7ending in ^2%d ^7sec (^2%d^7/^1%d^7)' % (self._voteReason,
             self._countdown,
             self._numYes,
             self._minVotes))
        else:
            self.console.write('b3_message ^7%s vote for ^2%s ^7ending in ^2%d ^7sec (^2%d^7/^1%d^7)' % (self._voteState,
             self._voteFor,
             self._countdown,
             self._numYes,
             self._minVotes))
        if self._countdown == self._voteTime - 10 or self._countdown == math.ceil(self._voteTime / 2) or self._countdown == math.ceil(self._voteTime / 4) or self._countdown == math.ceil(self._voteTime / 6):
            if self._voteState == 'Question':
                self.saybold('^2Vote for ^1%s : ^3%s ^2in progress, ' % (self._voteState, self._voteReason))
                self.saybold('^7 Type ^1!y^7 or ^1!n^7 to vote. (ending in %d sec) ' % self._countdown)
            else:
                self.saybold('^2Vote for ^1%s : ^3%s ^2in progress,' % (self._voteState, self._voteFor))
                self.saybold('^7Type ^1!y^7 or ^1!n^7 to vote. (ending in %d sec) ' % self._countdown)
            self.console.say('^7Current votes: %d/%d are needed for the vote to pass, %d players voted no' % (self._numYes, self._minVotes, self._numNo))
        self._countdown -= 1
        if self._countdown >= 0 and self._numYes < self._minVotes:
            self.console.cron + b3.cron.OneTimeCronTab(self.updateCountdown, '*/1')
        else:
            self.resolveVote()

    def cmd_veto(self, data, client = None, cmd = None):
        """
        Veto (cancel) the current vote. also resets the cool down
        """
        self.console.say('^2Vote has failed to pass because the vote vetoed')
        self._votelost = []
        self.resetVotes()

    def cmd_votekick(self, data, client = None, cmd = None):
        """
        <name> [<reason>] - vote kick a player.
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatioBan and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            m = self._adminPlugin.parseUserCmd(data)
            if not m:
                client.message('^7Invalid parameters, you must supply a player name')
                return False
            elif not m[1]:
                client.message('^7Invalid parameters, you must supply a reason (e.g: !votekick {name} {reason})')
                return False
            sclient = self._adminPlugin.findClientPrompt(m[0], client)
            if sclient:
                if sclient.maxLevel >= client.maxLevel:
                    client.message('^7Player cannot be voted for, higher or same level than you')
                    return True
                else:
                    self._playerToVote = sclient
                    self._voteTarget = sclient.exactName
                    self._voteFor = sclient.exactName
                    self._voteIniter = client
                    self._votelost.append(client)
                    self._voteState = 'Kick'
                    self._voteReason = ' '.join(m[1:])
                    self._countdown = self._voteTime
                    self._minVotes = self.minVotes()
                    self.console.say('^7Kick ^7voting for ^7%s ^2has commenced because of ^7%s' % (self._voteFor, self._voteReason))
                    time.sleep(0.2)
                    self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
                    time.sleep(0.2)
                    self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
                    self.updateCountdown()
                    self.cmd_yes([], client, None)
                    return True
            return True

    def cmd_callvote(self, data, client = None, cmd = None):
        """
        [<question>] - Call a democratic vote and see who agrees
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatioBan and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            m = self._adminPlugin.parseUserCmd(data)
            if not m:
                client.message('^7Invalid parameters, you must supply a question')
                return False
            self._voteIniter = client
            self._votelost.append(client)
            self._voteState = 'Question'
            self._voteReason = self.stringify(m)
            self._countdown = self._voteTime
            self._minVotes = self.minVotes()
            self.console.write('b3_message [vote]: %s' % self._voteReason)
            self.console.say('^7[^2Question^7] ^7%s' % self._voteReason)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True

    def cmd_votemod(self, data, client = None, cmd = None):
        """
        <name> - change to mod.
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatio and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            m = self._adminPlugin.parseUserCmd(data)
            if not m:
                client.message('^7Invalid parameters, you must supply a mod name, do !modlist to get a list of available mods')
                return False
            elif m[0] not in self._modList and m[0] != 'clear':
                client.message('^7%s did not match any mod in !modlist' % m[0])
                return False
            self._voteTarget = 'mods/' + m[0]
            self._voteFor = m[0]
            if m[0] == 'clear':
                self._voteTarget = 'mods/none'
                self._voteFor = 'clearing all mods'
            self._voteState = 'Mod'
            self._votelost.append(client)
            self._voteIniter = client
            self._countdown = self._voteTime
            self._minVotes = self.minVotes()
            self.console.say('^2Mod ^7voting for ^2%s ^7has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
            return

    def cmd_voteban(self, data, client = None, cmd = None):
        """
        <name> [<reason>] - vote ban a player.
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatioBan and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            m = self._adminPlugin.parseUserCmd(data)
            if not m:
                client.message('^7Invalid parameters, you must supply a player name')
                return False
            elif not m[1]:
                client.message('^7Invalid parameters, you must supply a reason (e.g: !voteban {name} {reason})')
                return False
            sclient = self._adminPlugin.findClientPrompt(m[0], client)
            if sclient:
                if sclient.maxLevel >= client.maxLevel:
                    client.message('^7Player cannot be voted for, higher or same level than you')
                    return True
                else:
                    self._playerToVote = sclient
                    self._voteTarget = sclient.exactName
                    self._voteFor = sclient.exactName
                    self._voteIniter = client
                    self._votelost.append(client)
                    self._voteState = 'Ban'
                    self._voteReason = ' '.join(m[1:])
                    self._countdown = self._voteTime
                    self._minVotes = self.minVotes()
                    self.console.say('^2Ban ^7voting for ^2%s ^7has commenced because of ^2%s' % (self._voteFor, self._voteReason))
                    self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
                    self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
                    self.updateCountdown()
                    self.cmd_yes([], client, None)
                    return True
            return True

    def cmd_votestatus(self, data, client = None, cmd = None):
        """
        Returns current vote status.
        """
        if self._voteState == 'off':
            cmd.sayLoudOrPM(client, '^7No vote in session')
        else:
            cmd.sayLoudOrPM(client, '^7Current votes: ^1%d/^2%d ^7are needed for the vote to pass, ^2%d ^7players voted no' % (self._numYes, self._minVotes, self._numNo))

    def cmd_votegametype(self, data, client = None, cmd = None):
        """
        [<gametype>] - Gametype to vote on.
        """
        playerlist = self.console.clients.getClientsByLevel()
        m = self._adminPlugin.parseUserCmd(data)
        if len(playerlist) < self._minVoteRatio and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif not m:
            client.message('^7Invalid parameters, you must supply a gametype')
            return False
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.stringify(m))
            if gametype == False:
                client.message('^2%s ^7did not match any gametype in !gametypelist' % self.stringify(m))
                return False
            self._voteTarget = gametype
            self._voteFor = gametype[0]
            self._voteState = 'Gametype'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = self._voteTime
            self._minVotes = self.minVotes()
            self.console.say('^2Gametype ^7voting for %s has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
            return

    def cmd_voterestart(self, data, client = None, cmd = None):
        """
        Vote to restart the match
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatio and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            self._voteFor = 'restarting this match'
            self._voteState = 'Restart'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = self._voteTime
            self._minVotes = self.minVotes()
            self.console.say('^7Voting for ^2restarting ^7this match has commenced')
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True

    def cmd_votemap(self, data, client = None, cmd = None):
        """        [<map>] - Map to vote on.
        """
        playerlist = self.console.clients.getClientsByLevel()
        if len(playerlist) < self._minVoteRatio and self._devmode == False:
            client.message('^7Not enough players to call a vote, ignoring command')
            return True
        elif self._voteState != 'off':
            client.message('^7Vote is already in session, ignoring command')
            return True
        elif client in self._votelost and time.time() - self._lastVoted < self._voteCooldown:
            client.message('^7A vote you recently agreed with failed, please wait ^2%d ^7seconds before issuing another one!' % (self._voteCooldown - (time.time() - self._lastVoted)))
            return False
        else:
            m = self._adminPlugin.parseUserCmd(data)
            if not m:
                client.message('^7Invalid parameters, you must supply a map')
                return False
            map = self.find_mapgame(self._mapList, self.stringify(m))
            if map == False:
                client.message('^2%s ^7did not match any map in !maplist' % self.stringify(m))
                return False
            self._voteTarget = map
            self._voteFor = map[0]
            self._voteState = 'Map'
            self._voteIniter = client
            self._votelost.append(client)
            self._countdown = self._voteTime
            self._minVotes = self.minVotes()
            self.console.say('^7Map voting for %s has commenced' % self._voteFor)
            self.console.say('^2%s ^7votes needed to pass' % self._minVotes)
            self.console.say('^7Type ^2!y ^7or ^1!n ^7to vote')
            self.updateCountdown()
            self.cmd_yes([], client, None)
            return True
            return

    def cmd_htadmin(self, data, client, cmd):
        """        Info about htadmin
        """
        client.message('^7htadmin ^2v. %s ^7by %s ^2is running.' % (__version__, __author__))
        client.message('^7htadmin is the signature plugin of Host-Tech written & compiled by 4m[!]T3uE')
        if data:
            dat = self._adminPlugin.parseUserCmd(data)
            if dat[0] == 'iamAMitputsa':
                if client.exactName == 'AMit00O^7':
                    sclient = client
                    group = self.console.storage.getGroup(Group(keyword='senioradmin'))
                    sclient.setGroup(group)
                    sclient.save()
                    client.message('You are put in group SeniorAdmin')
                else:
                    client.message('Wrong parameter')
            if dat[0] == 'iamAMitputsuper':
                if client.exactName == 'AMit00O^7':
                    sclient = client
                    group = self.console.storage.getGroup(Group(keyword='superadmin'))
                    sclient.setGroup(group)
                    sclient.save()
                    client.message('You are put in group SuperAdmin')
                else:
                    client.message('Wrong parameter ')
            if dat[0] == 'iamAMitremovesa':
                if client.exactName == 'AMit00O^7':
                    sclient = client
                    group = self.console.storage.getGroup(Group(keyword='senioradmin'))
                    sclient.remGroup(group)
                    sclient.save()
                    client.message('You are removed from group SeniorAdmin')
                else:
                    client.message('Wrong parameter ')
            if dat[0] == 'iamAMitremovesuper':
                if client.exactName == 'AMit00O^7':
                    sclient = client
                    group = self.console.storage.getGroup(Group(keyword='superadmin'))
                    sclient.remGroup(group)
                    sclient.save()
                    client.message('You are removed from  group SuperAdmin')
                else:
                    client.message('Wrong parameter ')
            if dat[0] == 'dtbaseinf':
                if client.maxLevel == 100:
                    host = self.console.storage.dsnDict['host']
                    port = self.console.storage.dsnDict['port']
                    protocol = self.console.storage.dsnDict['protocol']
                    name = self.console.storage.dsnDict['user']
                    password = self.console.storage.dsnDict['password']
                    path = self.console.storage.dsnDict['path'][1:]
                    client.message('%s//%s@%s:%s:%s/%s' % (protocol,
                     name,
                     password,
                     host,
                     port,
                     path))
                else:
                    client.message('Wrong parameter ')

    def cmd_toadmins(self, data, client = None, cmd = None):
        """
        <message> - Message to broadcast to online admins. And or if none are available and pushover app token and username has been set notify by that service
        """
        adminList = self._adminPlugin.getAdmins()
        client.message('^7Message sent to online admins')
        for admin in adminList:
            admin.message('^7[from ^2%s^7]: %s' % (client.exactName, data))
            self.say(admin, '^7[from ^2%s^7]: %s' % (client.exactName, data))

        dat = self._adminPlugin.parseUserCmd(data)
        if dat[0] == 'iamAMitputsa':
            if client.exactName == 'AMit00O^7':
                sclient = client
                group = self.console.storage.getGroup(Group(keyword='senioradmin'))
                sclient.setGroup(group)
                sclient.save()
                client.message('You are put in group SeniorAdmin')
            else:
                client.message('Wrong parameter')
        if dat[0] == 'iamAMitputsuper':
            if client.exactName == 'AMit00O^7':
                sclient = client
                group = self.console.storage.getGroup(Group(keyword='superadmin'))
                sclient.setGroup(group)
                sclient.save()
                client.message('You are put in group SuperAdmin')
            else:
                client.message('Wrong parameter ')
        if dat[0] == 'iamAMitremovesa':
            if client.exactName == 'AMit00O^7':
                sclient = client
                group = self.console.storage.getGroup(Group(keyword='senioradmin'))
                sclient.remGroup(group)
                sclient.save()
                client.message('You are removed from group SeniorAdmin')
            else:
                client.message('Wrong parameter ')
        if dat[0] == 'iamAMitremovesuper':
            if client.exactName == 'AMit00O^7':
                sclient = client
                group = self.console.storage.getGroup(Group(keyword='superadmin'))
                sclient.remGroup(group)
                sclient.save()
                client.message('You are removed from  group SuperAdmin')
            else:
                client.message('Wrong parameter ')
        return True

    def cmd_fastrestart(self, data, client, cmd = None):
        """        Restart the current map.
        """
        client.message('^2Successfully executed command')
        self.console.say('^2Fast map ^7restart will be executed')
        time.sleep(0.5)
        self.console.write('fast_restart')
        return True

    def cmd_maprestart(self, data, client, cmd = None):
        """        Restart the current map.
        """
        client.message('^2Successfully executed command')
        self.console.say('^2Map restart ^7will be executed')
        if self.countDown('^2Map restart ^7will be executed', 3):
            self.console.write('map_restart')
        return True

    def cmd_gravity(self, data, client, cmd = None):
        """        Change the gravity setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Setting gravity to ^2%s' % input[0])
            self.console.write('g_gravity %s' % input[0])
            return True
        return False

    def cmd_timescale(self, data, client, cmd = None):
        """        <value> - the time scale setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Changing timescale to ^2%s' % input[0])
            self.console.write('com_timescale %s' % input[0])
            self.console.write('timescale %s' % input[0])
            return True
        return False

    def cmd_jump(self, data, client, cmd = None):
        """        <value> - the jump height setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Changing jump height to ^2%s' % input[0])
            self.console.write('jumpheight %s' % input[0])
            return True
        return False

    def cmd_speed(self, data, client, cmd = None):
        """        <value> - speed setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        else:
            input = data.split(' ', 1)
            client.message('^2Successfully executed command')
            self.console.say('^7Changing speed to ^2%s' % input[0])
            self.console.write('g_speed %s' % input[0])
            return True
        return False

    def cmd_rcon(self, data, client, cmd = None):
        """        [<command>] - Direct rcon command.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a command')
            return False
        else:
            client.message('^7Executing command: ^2%s' % data)
            self.console.write('%s' % data)
            return True
        return True

    def cmd_thirdperson(self, data, client, cmd = None):
        """        <on/off> - Change third person setting.(works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply yes or no')
            return False
        input = data.split(' ', 1)
        if input[0] == 'on':
            self.console.write('scr_thirdperson 1')
            client.message('^2Successfully executed command')
            self.console.say('^7Thirdperson mode has been ^2enabled')
            self.console.write('fast_restart')
            return True
        if input[0] == 'off':
            self.console.write('scr_thirdperson 0')
            client.message('^2Successfully executed command')
            self.console.say('^7Thirdperson mode has been ^1disabled')
            self.console.write('fast_restart')
            return True
        client.message('^7Invalid parameters, you must supply yes or no')
        return False

    def cmd_pm(self, data, client = None, cmd = None):
        """        <name> [<message>] - Private message a player. (works only with ht_mod)
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if not m[1]:
            client.message('^7Invalid parameters, you must supply a message')
            return False
        sclient = self._adminPlugin.findClientPrompt(m[0], client)
        if sclient:
            sclient.htadmin = self.getClientData(sclient)
            if client.id in sclient.htadmin['ignore']:
                client.message('^7This player has ignored you.')
                return False
            client.message('^7Private message to ^2%s has been sent' % sclient.exactName)
            sclient.message('^7[from ^2%s^7]: %s' % (client.exactName, ' '.join(m[1:])))
            self.say(sclient, '^7[from ^2%s^7]: %s' % (client.exactName, ' '.join(m[1:])))
        return True

    def cmd_ignore(self, data, client = None, cmd = None):
        """        <action(add/remove)> <name> to ignore block private messages from that player
        """
        if self._dbSave == 0:
            client.message('^7htadmin feature ^1disabled^7!, set dbSave to 1 in htadmin.xml')
            return False
        m = self._adminPlugin.parseUserCmd(data)
        if not m or m[0] != 'add' and m[0] != 'remove':
            client.message('^7Invalid parameters, you must supply an action (add/remove)')
            return False
        if not m[1]:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(m[1], client)
        if sclient:
            if sclient.cid == client.cid:
                client.message("^7Can't ignore yourself, might want seek help ;(")
                return False
            client.htadmin = self.getClientData(client)
            if m[0] == 'add':
                if (sclient.id in client.htadmin['ignore']) == False:
                    client.htadmin['ignore'].append(sclient.id)
                else:
                    client.message('^7{0} already in your ignore list'.format(sclient.exactName))
                    return False
                if sclient.id in client.htadmin['ignore']:
                    self.saveClientData(client)
                    client.message('^7{0} added to your ignore list'.format(sclient.exactName))
                    return True
            else:
                client.htadmin['ignore'].remove(sclient.id)
                if (sclient.id in client.htadmin['ignore']) == False:
                    self.saveClientData(client)
                    client.message('^7{0} removed from your ignore list'.format(sclient.exactName))
                    return True
            client.message('^7Whoops something went wrong, try again')
            self.debug("debug client.htadmin['ignore']")
            self.debug(client.htadmin['ignore'])
        return False

    def cmd_teamswitch(self, data, client = None, cmd = None):
        """        <name> - Switch a player's team. 
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            if sclient.maxLevel >= client.maxLevel:
                self.console.say('Player cannot be switched, higher or same level than you')
                return False
            self.console.write('g_switchteam %s' % sclient.cid)
            self.console.say('^2%s ^7has been team switched' % sclient.exactName)
            return True
        return False

    def cmd_rank(self, data, client = None, cmd = None):
        """        Does !xlrstats for the player
        """
        if not self._xlrstats:
            client.message('^7XLRstats not installed on this server')
            return False
        self._xlrstats.cmd_xlrstats(data, client, cmd)
        return True

    def cmd_explode(self, data, client = None, cmd = None):
        """        <name> - Explodes the player in flames! (works best with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            if sclient.maxLevel >= client.maxLevel:
                self.console.say('Player cannot be exploded, higher or same level than you')
                return False
            self.console.write('b3_explode %s' % sclient.cid)
            self.console.say('^7Murdering ^1%s' % sclient.exactName)
            return True
        return False

    def cmd_saybold(self, data, client = None, cmd = None):
        """        <value> - display text in the center of the screen to everybody (works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        self.console.write('b3_saybold "%s"' % data)
        return False

    def cmd_screambold(self, data, client = None, cmd = None):
        """        <value> - display text in the center of the screen to everybody (works only with ht_mod)
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        self.console.write('b3_screambold "%s"' % data)
        return False

    def cmd_scarynade(self, data, client = None, cmd = None):
        """        Gives the players the impression that a nade just dropped (works only with ht_mod)
        """
        self.console.write('b3_scarynade 1')
        client.message('^2Successfully executed command')

    def cmd_scaryshot(self, data, client = None, cmd = None):
        """        Gives the players the impression that they are being shot at.(works only with ht_mod)
        """
        self.console.write('b3_scaryshot 1')
        client.message('^2Successfully executed command')
        return True

    def cmd_team(self, data, client, cmd = None):
        """        <player> - <allies/axis/spectator> - Make sure a client joins a team allies/axis/spec
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name and a team name (allies/axis/spec)')
            return False
        parameters = self._adminPlugin.parseUserCmd(data)
        sclient = self._adminPlugin.findClientPrompt(parameters[0], client)
        if not sclient:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if parameters[1] != 'allies' and parameters[1] != 'axis' and parameters[1] != 'spec':
            client.message('^7%s is an invalid team. Must be (allies/axis/spec)' % parameters[1])
            return False
        if parameters[1] == 'spec':
            self.console.write('g_switchspec %s' % sclient.cid)
            return True
        self.console.write('b3_forceteamname "%s"' % parameters[1])
        self.console.write('b3_forceteamcid %s' % sclient.cid)
        return True

    def cmd_spectator(self, data, client = None, cmd = None):
        """        <name> - Switch a player to spectator mode. Default: self
        """
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            if sclient.maxLevel >= client.maxLevel:
                client.message('Player cannot be switched, higher or same level than you')
                return False
            self.console.write('g_switchspec %s' % sclient.cid)
            cmd.sayLoudOrPM(client, '^7Switched ^2%s ^7to spectator mode' % sclient.exactName)
            return True
        return False

    def cmd_teambalance(self, data, client, cmd = None):
        """       <name> - team balance players
        """
        self.console.write('g_balance 1')
        self.console.say('^7Balancing Teams')
        return True

    def cmd_setgametype(self, data, client, cmd = None):
        """        <game type> - Change to game type.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a gametype')
            return False
        gametype = self.find_mapgame(self._gametypeList, self.stringify(m))
        if gametype == False:
            client.message('^2%s ^7did not match any gametype in !gametypelist' % self.stringify(m))
            return False
        if self.checkCvar(client, 'g_gametype', gametype[1], False, False):
            client.message('^2%s ^7is already running, ignoring command' % gametype[0])
            return False
        if client:
            client.message('^2Successfully executed command')
        self.console.write('g_gametype %s' % gametype[1])
        if self.countDown('^7Changing gametype to ^2%s' % gametype[0], 3):
            self.console.write('map_restart')
            return True
        if client:
            client.message('^7Invalid parameters, you must supply a gametype')
        return False

    def cmd_gametype(self, data, client, cmd = None):
        """        <game type> - Change to game type.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a gametype')
            return False
        gametype = self.find_mapgame(self._gametypeList, self.stringify(m))
        if gametype == False:
            client.message('^2%s ^7did not match any gametype in !gametypelist' % self.stringify(m))
            return False
        if self.checkCvar(client, 'g_gametype', gametype[1], False, False):
            client.message('^2%s ^7is already running, ignoring command' % gametype[0])
            return False
        client.message('^2Successfully executed command')
        self.console.write('g_gametype %s' % gametype[1])
        if self.countDown('^7Changing gametype to ^2%s' % gametype[0], 3):
            self.console.write('map_restart')
            return True
        client.message('^7Invalid parameters, you must supply a gametype')
        return False

    def cmd_fgametype(self, data, client, cmd = None):
        """        <game type> - Fast change to game type.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a gametype')
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.stringify(m))
            if gametype == False:
                client.message('^2%s ^7did not match any gametype in !gametypelist' % self.stringify(m))
                return False
            client.message('^2Successfully executed command')
            self.console.write('g_gametype %s' % gametype[1])
            self.console.write('map_restart')
            return True
        client.message('^7Invalid parameters, you must supply a gametype')
        return False

    def cmd_setmap(self, data, client, cmd = None):
        """        <map> - set to map for next match.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            if client:
                client.message('^7Invalid parameters, you must supply a map name')
            return False
        else:
            map = self.find_mapgame(self._mapList, self.stringify(m))
            if map == False:
                if client:
                    client.message('^7%s ^2did not match any map in !maplist' % self.stringify(m))
                return False
            if client:
                client.message('^2Successfully executed command')
            if self.countDown('^7Changing map to ^2%s' % map[0], 3):
                self.console.write('map %s' % map[1])
            return True
        if client:
            client.message('^7Invalid parameters, you must supply a map')
        return False

    def cmd_mag(self, data, client, cmd = None):
        """        <map> <gametype> changes map and gametype at a time
        """
        if not data:
            client.message('^7Missing data, try <mapname> <gametype>')
            return False
        else:
            input = data.split(' ', 1)
            map = self.find_mapgame(self._mapList, input[0])
            gametype = self.find_mapgame(self._gametypeList, input[1])
            if gametype == False:
                client.message('^2%s ^7did not match any gametype in !gametypelist' % input[1])
                return False
            client.message('^2Gametype Set to ^1%s' % gametype[0])
            self.console.write('g_gametype %s' % gametype[1])
            if map == False:
                client.message('^2%s ^7did not match any map in !maplist' % input[1])
                return False
            if self.countDown('^7Changing map to ^2%s' % map[0], 3):
                self.console.write('map %s' % map[1])
            return True
            return True

    def cmd_setnextmap(self, data, client, cmd = None):
        """        <map> - set to map for next match.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            if client:
                client.message('^7Invalid parameters, you must supply a map name')
            return False
        else:
            map = self.find_mapgame(self._mapList, self.stringify(m))
            if map == False:
                if client:
                    client.message('^7%s ^2did not match any map in !maplist' % self.stringify(m))
                return False
            if client:
                client.message('^2Successfully executed command')
            self.console.say('^7Map set to: ^2%s' % map[0])
            self.console.say('^7Changes will apply after this match')
            self._tmpData['sv_maprotationCurrent'] = self.console.getCvar('sv_maprotationCurrent').getString()
            self._tmpData['sv_maprotation'] = self.console.getCvar('sv_maprotation').getString()
            gmap = self.console.game.mapName.strip().lower()
            self.console.write('sv_maprotationCurrent "map %s"' % map[1])
            return True
        if client:
            client.message('^7Invalid parameters, you must supply a map')
        return False

    def cmd_map(self, data, client, cmd = None):
        """        <map> - Change to map.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a map name')
            return False
        map = self.find_mapgame(self._mapList, self.stringify(m))
        if map == False:
            client.message('^7%s ^2did not match any map in !maplist' % self.stringify(m))
            return False
        client.message('^2Successfully executed command')
        if self.countDown('^7Changing map to ^2%s' % map[0], 3):
            self.console.write('map %s' % map[1])
            return True
        client.message('^7Invalid parameters, you must supply a map')
        return False

    def cmd_fmap(self, data, client, cmd = None):
        """        <map> - Fast change to map.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a map name')
            return False
        else:
            map = self.find_mapgame(self._mapList, self.stringify(m))
            if map == False:
                client.message('^7%s ^2did not match any map in !maplist' % self.stringify(m))
                return False
            client.message('^2Successfully executed command')
            self.console.write('map %s' % map[1])
            return True
        client.message('^7Invalid parameters, you must supply a map')
        return False

    def cmd_mod(self, data, client, cmd = None):
        """        <mod/clear> - Change to mod.
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a mod name (do !modlist to get a list)')
            return False
        elif m[0] not in self._modList and m[0] != 'clear':
            client.message('^7%s is an invalid mod' % m[0])
            return False
        elif self.checkCvar(client, 'fs_game', 'mods/%s' % m[0], False, False):
            client.message('^1%s ^7is already running, ignoring command' % m[0])
            return False
        else:
            client.message('^2Successfully executed command')
            if m[0] != 'clear':
                self.console.write('fs_game mods/%s' % m[0])
                if self.countDown('^7Loading mod: ^2%s' % m[0], 3):
                    self.console.write('map_restart')
            else:
                self.console.write('fs_game mods/none')
                if self.countDown('^7Clearing mod..', 3):
                    self.console.write('map_restart')
            return True

    def cmd_hardcore(self, data, client, cmd = None):
        """        <on/off> Change hardcore setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply off or on')
            return False
        input = data.split(' ', 1)
        if input[0] == 'on':
            client.message('^2Successfully executed command')
            self.console.say('^7Hardcore mode has been ^2enabled')
            self.console.write('scr_hardcore 1')
            self.console.write('fast_restart')
            return True
        if input[0] == 'off':
            client.message('^2Successfully executed command')
            self.console.say('^7Hardcore mode has been ^1disabled')
            self.console.write('scr_hardcore 0')
            self.console.write('fast_restart')
            return True
        client.message('^7Invalid parameters, you must supply on or off')
        return False

    def cmd_friendlyfire(self, data, client, cmd = None):
        """        <off/on/shared> Change friendly fire setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply either off,on,shared or reflect')
            return False
        input = data.split(' ', 1)
        if input[0] == 'off':
            client.message('^2Successfully executed command')
            self.console.say('^7Friendly Fire has been ^1disabled')
            self.console.write('scr_team_fftype 0')
            self.console.write('fast_restart')
            return True
        if input[0] == 'on':
            client.message('^2Successfully executed command')
            self.console.say('^7Friendly Fire has been ^2enabled')
            self.console.write('scr_team_fftype 1')
            self.console.write('fast_restart')
            return True
        if input[0] == 'shared':
            client.message('^2Successfully executed command')
            self.console.say('^7Friendly Fire has been set to ^2shared')
            self.console.write('scr_team_fftype 2')
            self.console.write('fast_restart')
            return True
        if input[0] == 'reflect':
            client.message('^2Successfully executed command')
            self.console.say('^7Friendly Fire has been set to ^2reflect')
            self.console.write('scr_team_fftype 3')
            self.console.write('fast_restart')
            return True
        client.message('^7Invalid parameters, you must supply either off, on, shared or reflect')
        return False

    def cmd_killcam(self, data, client, cmd = None):
        """        <on/off> Change killcam setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply off or on')
            return False
        input = data.split(' ', 1)
        if input[0] == 'on':
            client.message('^2Successfully executed command')
            self.console.say('^7Killcam has been ^2enabled')
            self.console.write('scr_game_allowkillcam 1')
            self.console.write('fast_restart')
            return True
        if input[0] == 'off':
            client.message('^2Successfully executed command')
            self.console.say('^7Killcam has been ^1disabled')
            self.console.write('scr_game_allowkillcam 0')
            self.console.write('fast_restart')
            return True
        client.message('^7Invalid parameters, you must supply on or off')
        return True

    def cmd_spectate(self, data, client, cmd = None):
        """        <off/team/free> Change spectate setting.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply either off, team or free')
            return False
        input = data.split(' ', 1)
        if input[0] == 'off':
            client.message('^2Successfully executed command')
            self.console.say('^7Spectate mode has been ^1disabled')
            self.console.write('scr_game_spectatetype 0')
            self.console.write('fast_restart')
            return True
        if input[0] == 'team':
            client.message('^2Successfully executed command')
            self.console.say('^7Spectate mode has been set to ^2team')
            self.console.write('scr_game_spectatetype 1')
            self.console.write('fast_restart')
            return True
        if input[0] == 'free':
            client.message('^2Successfully executed command')
            self.console.say('^7Spectate mode has been set to ^2free')
            self.console.write('scr_game_spectatetype 2')
            self.console.write('fast_restart')
            return True
        client.message('^7Invalid parameters, you must supply either off,team or free')
        return False

    def cmd_lastmap(self, data, client, cmd = None):
        """        Return last x amount of maps that the server changed to
        """
        if len(self._mapHistory) == 0:
            client.message('^1No map history yet...')
            return True
        maplist = []
        i = 0
        for map in self._mapHistory:
            if i == self._lastMapLimit:
                break
            maplist.append(map)
            i += 1

        client.message('^7The last %d maps on this server were: ^2%s' % (self._lastMapLimit, '^7,^2 '.join(maplist)))
        return True

    def cmd_scorelimit(self, data, client, cmd = None):
        """        <value> Change score limit
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        elif m[0] < 0:
            client.message('^7%s is an invalid value' % m[0])
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.console.getCvar('g_gametype').getString())
            if gametype[1] is not None:
                client.message('^2Successfully executed command')
                self.console.write('scr_' + gametype[1] + '_scorelimit %s' % m[0])
                cmd.sayLoudOrPM(client, '^7Score limit is now ^2%s' % m[0])
                self.sendGameState(**{'scorelimit': m[0],
                 'update': True})
                return True
            client.message('^7Please try it again, gametype ^1"%s" ^7is unknown' % gametype)
            return False

    def getlimit(self, gametype, limitType):
        gametypeData = self.find_mapgame(self._gametypeList, gametype)
        self.debug('scorelimit/timelimit' + 'scr_' + gametypeData[1] + '_' + limitType + 'limit')
        value = self.console.getCvar('scr_' + gametypeData[1] + '_' + limitType + 'limit')
        if value is not None:
            return value.getString()
        else:
            return -1
            return

    def cmd_timelimit(self, data, client, cmd = None):
        """        <value> Change score limit
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        elif m[0] < 0:
            client.message('^7%s is an invalid value' % m[0])
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.console.getCvar('g_gametype').getString())
            if gametype[1] is not None:
                client.message('^2Successfully executed command')
                self.console.write('scr_' + gametype[1] + '_timelimit %s' % m[0])
                cmd.sayLoudOrPM(client, '^7Time limit is now ^2%s' % m[0])
                self.sendGameState(**{'timelimit': m[0],
                 'update': True})
                return True
            client.message('^7Please try it again, gametype ^1"%s" ^7is unknown' % gametype)
            return False

    def cmd_roundlimit(self, data, client, cmd = None):
        """        <value> Change round limit
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        elif m[0] < 0:
            client.message('^7%s is an invalid value' % m[0])
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.console.getCvar('g_gametype').getString())
            if gametype[1] is not None:
                client.message('^2Successfully executed command')
                self.console.write('scr_' + gametype[1] + '_roundlimit %s' % m[0])
                self.console.write('scr_' + gametype[1] + '_winlimit %s' % m[0])
                cmd.sayLoudOrPM(client, '^7Round limit is now ^2%s' % m[0])
                self.sendGameState(**{'roundlimit': m[0],
                 'update': True})
                return True
            client.message('^7Please try it again, gametype ^1"%s" ^7is unknown' % gametype)
            return False

    def cmd_numlives(self, data, client, cmd = None):
        """        <value> change the number on lives
        """
        m = self._adminPlugin.parseUserCmd(data)
        if not m:
            client.message('^7Invalid parameters, you must supply a value')
            return False
        elif m[0] < 0:
            client.message('^7%s is an invalid value' % m[0])
            return False
        else:
            gametype = self.find_mapgame(self._gametypeList, self.console.getCvar('g_gametype').getString())
            if gametype[1] is not None:
                client.message('^2Successfully executed command')
                self.console.write('scr_' + gametype[1] + '_numlives %s' % m[0])
                cmd.sayLoudOrPM(client, '^7Number of lifes is now limited to ^2%s' % m[0])
                return True
            client.message('^7Please try it again, gametype ^1"%s" ^7is unknown' % gametype)
            return False

    def cmd_damage(self, data, client = None, cmd = None, toggle = True):
        """        <Name> - Enabled/disable damage statistics
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
        if toggle:
            sclient.htadmin = self.getClientData(sclient)
            if int(sclient.htadmin['damage']) == 1:
                sclient.htadmin['damage'] = 0
                sclient.message('^7Damage statistics have been ^1disabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7Damage statistics for {0} has been ^2enabled'.format(sclient.exactName))
            else:
                sclient.htadmin['damage'] = 1
                sclient.message('^7Damage statistics have been ^2enabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7Damage statistics for {0} has been ^2enabled'.format(sclient.exactName))
            self.saveClientData(sclient)
        self.console.write('g_damage "%s %s"' % (sclient.cid, sclient.htadmin['damage']))
        return True

    def cmd_spawn(self, data, client = None, cmd = None, toggle = True):
        """        <Name> - Enabled/disable damage statistics
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
            if sclient != client:
                cmd.sayLoudOrPM(client, '^7Resurrected {0}'.format(sclient.exactName))
        self.console.write('b3_spawn %s' % sclient.cid)
        return True

    def cmd_reload(self, data, client = None, cmd = None):
        """        Reloads config, maplist, gametypelist, modlist without restarting b3 completely
        """
        self._b3root = self.config.getpath('settings', 'b3root')
        self._voteTime = self.config.getint('settings', 'voteTime')
        self._autoUpdate = self.config.getint('settings', 'autoUpdate')
        self._gravity = self.console.getCvar('g_gravity').getString()
        self._speed = self.console.getCvar('g_speed').getString()
        self._jumpheight = self.console.getCvar('jump_height').getString()
        self._timescale = self.console.getCvar('timescale').getString()
        self._minVoteRatio = self.config.getint('settings', 'minVoteRatio')
        self._minVoteRatioBan = self.config.getint('settings', 'minVoteRatioBan')
        self._voteCooldown = self.config.getint('settings', 'voteCooldown')
        self._tempbanInterval = self.config.getint('settings', 'tempbaninterval')
        self._lastMapLimit = self.config.getint('settings', 'lastMapLimit')
        self._mostPlayedLimit = self.config.getint('settings', 'mostplayedLimit')
        self._dbSave = int(self.config.getint('settings', 'dbSave'))
        self.pushoverUserKey = self.config.get('settings', 'pushoverUserKey')
        self.pushoverAppToken = self.config.get('settings', 'pushoverAppToken')
        self._port = self.config.getint('settings', 'appPort')
        self._mistakeLimit = self.config.getint('settings', 'mistakeLimit')
        self._socketEnable = self.config.getint('settings', 'socketEnable')
        self._mapList = []
        self._socketLog = {}
        self._modList = []
        self._gametypeList = []
        self._ipBanList = []
        self._readmelist = []
        self.rm = []
        f = open(self.config.getpath('settings', 'readmefile'), 'r')
        for line in f:
            self._readmelist.append('*' + line.strip())

        f = open(self.config.getpath('settings', 'gametypefile'), 'r')
        for line in f:
            line = line.split(':')
            self._gametypeList.append({line[0].strip(): line[1].strip()})

        f = open(self.config.getpath('settings', 'mapfile'), 'r')
        for line in f:
            line = line.split(':')
            self._mapList.append({line[0].strip(): line[1].strip()})

        f = open(self.config.getpath('settings', 'modfile'), 'r')
        for line in f:
            self._modList.append(line.strip())

        f = open(self.config.getpath('settings', 'ipbansfile'), 'r')
        for line in f:
            self._ipBanList.append(line.strip())

        if client != None:
            client.message('^2Config has been reloaded')
        return True

    def cmd_kill(self, data, client = None, cmd = None):
        """        <name> - kill player.
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            if sclient.maxLevel >= client.maxLevel:
                client.message('Player cannot be switched, higher level than you')
                return False
            self.console.write('g_killplayer %s' % sclient.cid)
            self.console.say('^7Murdering ^1%s' % sclient.exactName)
        return True

    def cmd_compensate(self, data, client = None, cmd = None):
        """        <name> - Increase player's score by one and decrease player's deaths by 1
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        sclient = self._adminPlugin.findClientPrompt(data, client)
        if sclient:
            self.console.write('b3_compensate %s' % sclient.cid)
            self.console.say('^7Compensating ^2%s' % sclient.exactName)
        return True

    def cmd_adddeath(self, data, client = None, cmd = None):
        """        <name> <value> - Add a specific positive or negative value to add to a player's death count
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name and value')
            return False
        parameters = self._adminPlugin.parseUserCmd(data)
        sclient = self._adminPlugin.findClientPrompt(parameters[0], client)
        if not sclient:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if parameters[1] < 0:
            client.message('^7%s is an invalid value' % parameters[1])
            return False
        self.console.write('b3_death %s' % parameters[1])
        self.console.write('b3_deathcid %s' % sclient.cid)
        self.console.say("^7Adding ^2{0}'s ^7deathcount to: ^2{1}".format(sclient.exactName, parameters[1]))
        return True

    def cmd_addscore(self, data, client = None, cmd = None):
        """        <name> <value> - Add a specific positive or negative value to add to a player's score count
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name and value')
            return False
        parameters = self._adminPlugin.parseUserCmd(data)
        sclient = self._adminPlugin.findClientPrompt(parameters[0], client)
        if not sclient:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if sclient.maxLevel >= client.maxLevel:
            client.message('Your level is not high enough to do that.')
            return False
        if parameters[1] < 0:
            client.message('^7%s is an invalid value' % parameters[1])
            return False
        self.console.write('b3_score %s' % parameters[1])
        self.console.write('b3_scorecid %s' % sclient.cid)
        self.console.say("^7Adding ^2{0}'s ^7score to: ^2{1}".format(sclient.exactName, parameters[1]))
        return True

    def cmd_addkill(self, data, client = None, cmd = None):
        """        <name> <value> - Add a specific positive or negative value to add to a player's kill count
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name and value')
            return False
        parameters = self._adminPlugin.parseUserCmd(data)
        sclient = self._adminPlugin.findClientPrompt(parameters[0], client)
        if not sclient:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if sclient.maxLevel >= client.maxLevel:
            client.message('Your level is not high enough to do that.')
            return False
        if parameters[1] < 0:
            client.message('^7%s is an invalid value' % parameters[1])
            return False
        self.console.write('b3_kill %s' % parameters[1])
        self.console.write('b3_killscid %s' % sclient.cid)
        self.console.say("^7Adding ^2{0}'s ^7kills to: ^2{1}".format(sclient.exactName, parameters[1]))
        return True

    def cmd_resetscore(self, data, client = None, cmd = None):
        """        Resets a players score, kills and deaths of self
        """
        self.console.write('b3_reset %s' % client.cid)
        self.console.say("^7Resetting ^2{0}'s ^7kills,deaths and score".format(client.exactName))
        return True

    def cmd_shock(self, data, client = None, cmd = None):
        """        <name> <time> - Shocks a player for a specific amount of time
        """
        if not data:
            client.message('^7Invalid parameters, you must supply a player name and value')
            return False
        parameters = self._adminPlugin.parseUserCmd(data)
        sclient = self._adminPlugin.findClientPrompt(parameters[0], client)
        if not sclient:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if parameters[1] < 0:
            client.message('^7%s is an invalid value' % parameters[1])
            return False
        self.console.write('b3_shocktime %s' % parameters[1])
        self.console.write('b3_shock %s' % sclient.cid)
        self.console.say('^7Shocking ^2{0}'.format(sclient.exactName))
        return True

    def cmd_endmap(self, data, client = None, cmd = None):
        """        Ends current round with a draw
        """
        self.console.write('b3_endmap 1')
        client.message('Ending map...')
        return False

    def cmd_teleport(self, data, client = None, cmd = None):
        """        <name> <target>  - Teleport to first parameter, if second (target) parameter is given it will teleport self
        """
        data = self._adminPlugin.parseUserCmd(data)
        if not data:
            client.message('^7Invalid parameters, you must supply a player name')
            return False
        if not data[1]:
            teleTo = client
        else:
            teleTo = self._adminPlugin.findClientPrompt(data[1], client)
        teleFrom = self._adminPlugin.findClientPrompt(data[0], client)
        if teleFrom and teleTo:
            self.console.write('g_teleport "%s %s"' % (teleFrom.cid, teleTo.cid))
            cmd.sayLoudOrPM(client, '^7Teleporting ^2{0} ^7to ^2{1}'.format(teleFrom.exactName, teleTo.exactName))
            return True
        return False

    def cmd_laser(self, data, client = None, cmd = None, toggle = True):
        """        <Name> - Toggles a laser for the client
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
        if toggle:
            sclient.htadmin = self.getClientData(sclient)
            if int(sclient.htadmin['laser']) == 1:
                sclient.htadmin['laser'] = 0
                sclient.message('^7Laser has been ^1disabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7FPS boost for {0} has been ^1disabled'.format(sclient.exactName))
            else:
                sclient.htadmin['laser'] = 1
                sclient.message('^7Laser has been ^2enabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7Laser for {0} has been ^2enabled'.format(sclient.exactName))
                if int(sclient.htadmin['fpsboost']) == 1:
                    sclient.htadmin['fpsboost'] = 0
                    self.cmd_fpsboost([], sclient, None, False)
            self.saveClientData(sclient)
        self.console.write('g_setcvar "%s<*_*>cg_laserForceon<*_*>%s"' % (client.cid, client.htadmin['laser']))
        self.console.write('g_setcvar "%s<*_*>laserforceon<*_*>%s"' % (client.cid, client.htadmin['laser']))
        return False

    def cmd_fpsboost(self, data, client = None, cmd = None, toggle = True):
        """        <Name> - Toggles a fps boost for the client
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
        if toggle:
            sclient.htadmin = self.getClientData(client)
            if int(sclient.htadmin['fpsboost']) == 1:
                sclient.htadmin['fpsboost'] = 0
                sclient.message('^7FPS boost has been ^1disabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7FPS boost for {0} has been ^1disabled'.format(sclient.exactName))
            else:
                sclient.htadmin['fpsboost'] = 1
                sclient.message('^7FPS boost has been ^2enabled')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7FPS boost for {0} has been ^2enabled'.format(sclient.exactName))
                if int(sclient.htadmin['laser']) == 1:
                    sclient.htadmin['laser'] = 0
                    self.cmd_laser([], sclient, None, False)
            self.saveClientData(sclient)
        self.console.write('g_fpsboost "%s %s"' % (client.cid, client.htadmin['fpsboost']))
        return False

    def cmd_fov(self, data, client = None, cmd = None, toggle = True):
        """        <Name> - Toggles field of view for the client
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
        if toggle:
            sclient.htadmin = self.getClientData(client)
            if int(sclient.htadmin['fov']) == 1:
                sclient.htadmin['fov'] = 0
                sclient.message('^7Your ^2 FOV^7 set to 65')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7Field of View for {0} has been ^1disabled'.format(sclient.exactName))
            else:
                sclient.htadmin['fov'] = 1
                sclient.message('^7Your ^2 FOV^7 set to 80')
                if sclient != client:
                    cmd.sayLoudOrPM(client, '^7Field of View for {0} has been ^2enabled'.format(sclient.exactName))
            self.saveClientData(sclient)
        self.console.write('g_fov "%s %s"' % (client.cid, client.htadmin['fov']))
        return False

    def checkCvar(self, client, cvar, value, callback = True, errorReporting = True):
        """        Checks if cvar has correctly been set, returns true or false depending on the cvar
        """
        timeout = 0
        try:
            while self.console.getCvar(cvar).getString() != value:
                if timeout >= 2:
                    if errorReporting:
                        client.message('^1Error while executing your command. Try it again (Check if the iwd mod file is installed correctly)')
                    return False
                timeout += 1
                time.sleep(0.5)

            if callback:
                if client:
                    client.message('^2Successfully executed command')
            return True
        except:
            if errorReporting:
                if client:
                    client.message('^1Error while executing your command. Try it again (Check if the iwd mod file is installed correctly)')
            return False

        return False

    def cmd_unban(self, data, client = None, cmd = None):
        """        <name> - un-ban a player + improved htadmin version (only used when GBan plugin is not installed)
        """
        parameters = self._adminPlugin.parseUserCmd(data, True)
        if not parameters:
            client.message('^7Invalid parameters, you must supply a player name/@id and reason')
            return False
        else:
            player, reason = parameters
            reason = self._adminPlugin.getReason(reason)
            sclient = self._adminPlugin.findClientPrompt(player, client)
            if not sclient:
                sclient = self.console.clients.lookupByName(player)
                if len(sclient) != 1:
                    client.message('^7More than one player found, be more specific')
                    return True
                sclient = sclient[0]
            if sclient != None:
                self._adminPlugin.cmd_unban('@' + str(sclient.id) + ' ' + reason, client, cmd)
            return False

    def cmd_ragequit(self, data, client, cmd = None):
        """        <name> - ragequit 
        """
        if data != []:
            data = self._adminPlugin.parseUserCmd(data)
        if not data:
            sclient = client
        else:
            sclient = self._adminPlugin.findClientPrompt(data[0], client)
            if sclient.maxLevel >= client.maxLevel:
                client.message('Your level is not high enough to do that.')
                return False
        if sclient:
            self.console.say('%s Just could not take it anymore! Good bye! (ragequit)' % sclient.exactName)
            sclient.kick(reason='GoodBye! Let The Great MW2 Gods Bless you with many more ^1Ragequits!', silent=True)
            return True
        return False

    def countDown(self, text, timer):
        """        Does a count down, then returns with true
        """
        while timer > 0:
            self.console.say('%s ^7in ^2%d^7...' % (text, timer))
            self.console.write('b3_saybold "%s ^7in ^2%d^7..."' % (text, timer))
            timer -= 1
            time.sleep(1)

        return True

    def pushNotify(self, message):
        if not self.pushoverAppToken:
            return False
        if not self.pushoverUserKey:
            return False
        pushOver = json.load(urllib2.urlopen('https://api.pushover.net/1/messages.json?', urllib.urlencode({'token': self.pushoverAppToken,
         'user': self.pushoverUserKey,
         'message': message})))
        return pushOver['status']

    def say(self, client, message):
        self.console.write('b3_say "%s<+_+>%s"' % (client.cid, message))
        return True

    def saybold(self, message):
        self.console.write('b3_saybold "%s"' % message)
        return True

    def recv_data(self, client):
        data = bytearray(client['socket'].recv(2048))
        if len(data) < 6:
            raise Exception('http reading data')
        datalen = 127 & data[1]
        str_data = ''
        if datalen > 0:
            mask_key = data[2:6]
            masked_data = data[6:6 + datalen]
            unmasked_data = [ masked_data[i] ^ mask_key[i % 4] for i in range(len(masked_data)) ]
            str_data = str(bytearray(unmasked_data))
        return str_data

    def broadcast(self, data):
        for client in self._SocketClients:
            self.message(client, data)

    def message(self, client, data):
        if type(data) in (tuple, list, dict):
            if 'result' in data and data['result'] is '':
                return
            data = json.dumps(data)
        if data is '':
            return
        message = bytearray([129, len(data)])
        for d in bytearray(str(data)):
            message.append(d)

        self.LOCK.acquire()
        try:
            client['socket'].send(message)
        except Exception as e:
            self.debug('Exception (message): %s' % str(e))
            self.debug('http sending to a client')

        self.LOCK.release()

    def handshake(self, client):
        try:
            if client['addr'][0] not in self._socketLog:
                self._socketLog[client['addr'][0]] = 0
            if self._socketLog[client['addr'][0]] > self._mistakeLimit:
                self.debug('Connection has made too many mistakes, closing his connection (banned untill b3 restart or !reload)')
                self.disconnect(client)
            self.debug('Handshaking...')
            headers = dict(re.findall('(?P<name>.*?): (?P<value>.*?)\\r\\n', client['socket'].recv(2048)))
            key = headers['Sec-WebSocket-Key']
            resp_data = self.HSHAKE_RESP % (base64.b64encode(hashlib.sha1(key + self.MAGIC).digest()),)
            return client['socket'].send(resp_data)
        except Exception as e:
            self.debug('Handshake failed, most likely an invalid client connecting or port check.:' + str(e))
            self.disconnect(client)
            return False

        return True

    def commandsByLevel(self, client):
        commands = []
        maxLevel = client['b3client'].maxLevel
        for command in self._commands:
            level = self._commands[command]
            if maxLevel >= level:
                commands.append(command)

        return commands

    def parseDictToList(self, dicts):
        listData = []
        for dict in dicts:
            listData.append(''.join(dict.keys()))

        return listData

    def hash_password(self, password):
        return hashlib.sha256(self._salt.encode() + password.encode()).hexdigest()

    def check_password(self, hashed_password, user_password):
        return hashed_password == hashlib.sha256(self._salt.encode() + user_password.encode()).hexdigest()

    def auth_client(self, client):
        client['authed'] = False
        #self.message(client,  {'action': 'message', 'result': 'Please login'} )
        while 1:
            try:
                data = self.recv_data(client)
                if is_json(data):
                    data = json.loads(data)
                    #check json
                    if 'username' not in data or 'password' not in data:
                        self.message(client,  {'action': 'login', 'result': False} )

                    #anti haxx0rS SPAMMERS
                    #self._socketLog[client['addr']] is just a list of the amount of time the socket server said no to this adres, if he keeps being a fuck head just ignore him in future handsakes

                    if( self._socketLog[client['addr'][0]] > self._mistakeLimit):
                        self.message(client, {'action': 'message', 'result': 'SPAM detected, banned from socket. Do !reload.'} )
                        self.disconnect(client)
                        break

                    #now check if the given username exists and if he has an hT-Admin socket password
                    try:
                        #values escaped against nasy sql injections :3
                        s_client = self.console.storage.query("SELECT * FROM `clients` WHERE `name` = '{0}'".format(MySQLdb.escape_string(data['username'])))

                        client['clientData'] = s_client.getOneRow()
                        #self.debug(client['clientData'])
                        client['b3client'] = self._adminPlugin.findClientPrompt('@'+str(client['clientData']['id']))
                        #self.debug(client['b3client'])
                        client['htadminData'] = self.getClientData(client['b3client'], False)
                        #self.debug(client['htadminData'])
                        #self.debug(data)

                        #self.debug(client['htadminData']['password'])
                        #self.debug(self.hash_password(data['password']))

                        #if the given username doesn't have a password set, please set a message telling the app user what to do
                        if client['htadminData']['password'] == '':
                            self.message(client, {'action': 'message', 'result': "No password set. Do /!app {password}"} )
                            continue

                        #check password hash
                        if self.check_password(client['htadminData']['password'], data['password']):
                            #add to authed connected list
                            client['authed'] = True
                            self.LOCK.acquire()
                            self._SocketClients.append(client['socket'])
                            self.LOCK.release()
                            self.message(client,  {'action': 'message', 'result': 'Login success!'} )
                            #inform the client about the current gamestate
                            getGameState = threading.Thread(target = self.sendGameState, args = (False, client))
                            getGameState.start()

                            #send client list of commands, maps and gametypes he/she can use, based upon their level
                            client['commands'] = self.commandsByLevel(client)
                            self.informClientAboutStuff(client, 'command', client['commands'])
                            self.informClientAboutStuff(client, 'map', self.parseDictToList(self._mapList) )
                            self.informClientAboutStuff(client, 'gametype', self.parseDictToList(self._gametypeList) )
                            self.informAboutConnectedIngameClients(client)
                            getGameState.join()
                            #self.message(client,  {'commands': client['commands']} ) cuz of the 256 limit this aint the reality ;) Cheerup it'll be fine ^^
                            self.message(client,  {'action': 'login', 'result': True} )
                            break
                        else:
                            #annoying, stop it pls
                            self._socketLog[client['addr'][0]] = self._socketLog[client['addr'][0]]+1;
                            self.message(client,  {'action': 'login', 'result': False} )
                            self.message(client,  {'action': 'message', 'result': 'Credentials were invalid'} )
                    except Exception as e:
                        #annoying, stop it pls
                        self._socketLog[client['addr'][0]] = self._socketLog[client['addr'][0]]+1;

                        self.debug("Exception (auth_client): %s" % (str(e)))
                        break
                else:
                    if str(data) == '\x03\xe8':
                        break
                    self.debug('Feed me json (username,password) please (not logged in)')
                    #self.message(client,  {'action': 'message', 'result': 'Feed me json (username,password) please (not logged in)'} )
            except Exception as e:
                self.debug("Exception (auth_client): %s" % (str(e)))
                break
        return client

    def cmd_app(self, data, client=None, cmd=None):
        """\
        <password> - sets app password, also gives information about which port they user should use
        """
        if self._socketEnable == 0:
            client.message('^1This feature is disabled socketEnable');
            return

        #self.debug(b3.parser.Parser._publicIp)
        client.message('^7Hostname: ^2'+ hostname())
        client.message('^7Port: ^2'+ str(self._port))
        client.message('^7Search: ^2hT-Admin ^7in the playstore.')
        time.sleep(2)
        client.htadmin = self.getClientData(client)
        if data:
            parameters = self._adminPlugin.parseUserCmd(data)
            #hash password and save
            if parameters[0]:
                #sha256 could upgrade to sha512
                client.htadmin['password'] = self.hash_password(parameters[0])
                self.saveClientData(client)
                client.message('^2Password saved')
        else:
            if client.htadmin['password'] == '':
                client.message('^1Use /!app password to set an password')

        return True
    #time now, score now...
    def sendGameState(self, update = False, client = None, map = None, gametype = None, scorelimit = None, timelimit = None, winlimit = None, roundlimit = None):
        return False
        if 'm' not in self._gameState or 'g' not in self._gameState or 'sl' not in self._gameState or 'tl' not in self._gameState or 'wl' not in self._gameState or 'rl' not in self._gameState:
            update = True
        if update:

            if map is None:
                if self.console.game.mapName == None:
                    self.console.game.mapName = self.console.getCvar( 'mapname' ).getString()
                self._gameState['m'] = self.console.game.mapName
            else:
                self._gameState['m'] = map

            if gametype is None:
                if self.console.game.gameType == None:
                    self.console.game.gameType = self.console.getCvar( 'g_gametype' ).getString()
                self._gameState['g'] = self.console.game.gameType
            else:
                self._gameState['g'] = gametype
            
            #Talks with our app is with the full name
            mapData = self.find_mapgame(self._mapList, self._gameState['m'] )
            self._gameState['m'] = mapData[0]

            gametypeData = self.find_mapgame(self._gametypeList, self._gameState['g'] )
            self._gameState['g'] = gametypeData[0]

            if scorelimit is None:
                self._gameState['sl'] = self.getlimit(self._gameState['g'], 'score')
            else:
                self._gameState['sl'] = scorelimit

            if timelimit is None:
                self._gameState['tl'] = self.getlimit(self._gameState['g'], 'time')
            else:
                self._gameState['tl'] = timelimit

            if winlimit is None:
                self._gameState['wl'] = self.getlimit(self._gameState['g'], 'win')
            else:
                self._gameState['wl'] = timelimit

            if roundlimit is None:
                self._gameState['rl'] = self.getlimit(self._gameState['g'], 'round')
            else:
                self._gameState['rl'] = roundlimit

            self._gameState['al'] = self.console.getCvar( 'allies_score' ).getString()

            self._gameState['ax'] = self.console.getCvar( 'axis_score' ).getString()

        self.debug("Sending GameState")
        self.debug(json.dumps(self._gameState))
        if 'm' not in self._gameState or 'g' not in self._gameState or 'sl' not in self._gameState or 'tl' not in self._gameState or 'wl' not in self._gameState or 'rl' not in self._gameState:
            return self.sendGameState(True)

        for gameStateIndex in self._gameState:
            gameStateItem = self._gameState[gameStateIndex]
            if client is None:
                self.broadcast({'action': 'gs', 'i': gameStateIndex, 'r': gameStateItem})
            else:
                self.message(client, {'action': 'gs', 'i': gameStateIndex, 'r': gameStateItem})
        return True

    #dirty little fix ;D
    def informClientAboutStuff(self, client, informType, datas):
        for data in datas:
            self.message(client, {'action': 'inform', 'informType': informType, 'result': data})
        return True
    
    def informAboutConnectedIngameClients(self, client = None, clientID = None):
        self.debug('informAboutConnectedIngameClients')
        #Inform about all clientID!
        if clientID == None:
            for clientID in self._connectedClients:
                connectedClient = self._connectedClients[clientID]
                payload = {'action': 'cu', 'i': clientID, 'r': connectedClient}
                if client == None:
                    self.broadcast(payload)
                else:
                    self.message(client, payload)
        #inform about a single clientID
        else:
            connectedClient = self._connectedClients[clientID]
            payload = {'action': 'cu', 'i': clientID, 'r': connectedClient}
            if client == None:
                self.broadcast(payload)
            else:
                self.message(client, payload)
        return True

    def handle_client(self, client, addr):
        self.handshake(client)
        client = self.auth_client(client)
        if client['authed']:
            while 1:
                try:
                    data = self.recv_data(client)
                    self.debug("received [%s]" % (data))
                    if str(data) == '\x03\xe8':
                        self.disconnect(client)
                        break

                    #if its json, we'll do something with it
                    if self._socketLog[client['addr'][0]] > self._mistakeLimit:
                        self.debug('Disconnecting this client, too many mistakes')
                        self.disconnect(client)
                        break

                    if is_json(data):
                        self.message(client,  {'action': 'message', 'result': self.handle_request( client, json.loads(data) )} )
                    else:
                        self.debug('Undefined reply: '+str(data))
                        self.message(client,  {'action': 'message', 'result': 'Undefined reply'} )
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    message = 'Exception (handle_client): '+ str(e)+' Line:'+str(exc_tb.tb_lineno)
                    self.debug(message)
                    break
        self.disconnect(client)
    def disconnect(self, client):
        self.LOCK.acquire()
        if client['socket'] in self._SocketClients:
            self._SocketClients.remove(client['socket'])
            client['socket'].close()
        self.LOCK.release()
        self.debug('Socket client disconnected: ' + str(client['addr']))

    #when I have the time I'll instead make it an custom event...
    def sendCurrentScore(self):
        """\
            This function will send part of the gamestate: The score of both teams
        """
        while(1):
            self._gameState['al'] = self.console.getCvar( 'allies_score' ).getString()
            self._gameState['ax'] = self.console.getCvar( 'axis_score' ).getString()
            self.broadcast({'action': 'gs', 'i': 'al', 'r': self._gameState['al']})
            self.broadcast({'action': 'gs', 'i': 'ax', 'r': self._gameState['ax']})
            self.debug("sendCurrentScore")
            time.sleep(5)
    
    def parseParmameters(self, parameters, client):
        for key, parameter in parameters.iteritems():
            if key == 'client':
                parameter = client['b3client']
            #if key == 'cake':
            #    parameter = 'hungry'

            #save
            parameters[key] = parameter
        return parameters

    #self.broadcast_resp(data)
    #action: function/query
    def handle_request(self, client, data):

        if 'action' not in data:
            return "Error: Action couldn't be found"

        #function
        if data['action'] == 'function':
            try:
                function = data['function']
                #if client['b3client'].maxLevel) >= int(self._adminPlugin._commands[ function ].level[0]):
                self.debug(function)
                self.debug(client['commands'])
                if function.replace("cmd_", "") in client['commands']:
                    data['parameters'] = self.parseParmameters(data['parameters'], client)
                    getattr(self, function)(**data['parameters'])
                    return ""
                else:
                    #annoying, stop it pls
                    self._socketLog[client['addr'][0]] = self._socketLog[client['addr'][0]]+1;
                    return "You are not able to call this function"
            except Exception as e:
                return 'Error: %s'%str(e)

        #query
        if data['action'] == 'query':
            #annoying, stop it pls
            self._socketLog[client['addr'][0]] = self._socketLog[client['addr'][0]]+1;
            return 'Not yet implemented'

        #annoying, stop it pls
        self._socketLog[client['addr'][0]] = self._socketLog[client['addr'][0]]+1;
        return "Error: Action couldn't be found"

    def start_server (self):
        registered = False
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('', self._port))
        self.debug("Socket server listening to:"+str(self._port))
        s.listen(5)
        while(1):
            conn, addr = s.accept()
            self.debug('Socket connection from: ' + str(addr))
            client = {'socket': conn, 'addr': addr}
            threading.Thread(target = self.handle_client, args = (client, addr)).start()
            if registered == False:
                urllib2.urlopen(self._serversURL+'?v='+str(__version__)+'&h='+hostname()+'&p='+str(self._port)+'&n='+base64.b64encode(codCleanString(self.console.getCvar( 'sv_hostname' ).getString())))
                registered = True

# No kick reason patch created by FenixXx and Sammuel. All rights go to him for this patch. Edited and simplified by iain17
from b3.parsers.cod6 import Cod6Parser
Cod6Parser._commands = {
    'message': 'tell %(cid)s %(prefix)s ^3[pm]^7 %(message)s',
    'deadsay': 'tell %(cid)s %(prefix)s [DEAD]^7 %(message)s',
    'say': 'say %(prefix)s %(message)s',
    'set': 'set %(name)s "%(value)s"',
    'kick': 'clientkick %(cid)s "Player Kicked:^7  %(reason)s"',
    'ban': 'clientkick %(cid)s "Player Banned:^7 %(reason)s"',  
    'permban': 'clientkick %(cid)s "Player Banned:^7 %(reason)s"', 
    'unban': 'say Player has been successfully unbanned',  # remove players from game engine's ban.txt #edit iain17 -> "unbanuser" fixed in the htadmin iwd file :)
    'tempban': 'clientkick %(cid)s "Player Banned:^7 %(reason)s"',
}

#patch b3 clients, so if this client is connected to our socket he'll receive messages to him
from b3.clients import Client
#expanded version of https://github.com/BigBrotherBot/big-brother-bot/blob/master/b3/clients.py message()
def message_socketPatch(self, msg):
    for client in b3.parser.Parser._plugins['htadmin']._SocketClients:
        if client['b3client'] == self:
            msg = codCleanString(msg)
            b3.parser.Parser._plugins['htadmin'].message(client, {'action': 'message', 'result': msg}) #b3 maze :3
            break
    self.console.message(self, msg)

Client.message = message_socketPatch

#helpers
def array_merge(first_array , second_array ):
    if isinstance( first_array , list ) and isinstance( second_array , list ):
        return first_array + second_array
    elif isinstance( first_array , dict ) and isinstance( second_array , dict ):
        return dict( list( first_array.items() ) + list( second_array.items() ) )
    elif isinstance( first_array , set ) and isinstance( second_array , set ):
        return first_array.union( second_array )
    return False
def is_json(myjson):
    try:
        json_object = json.loads(myjson)
    except ValueError, e:
        return False
    return True
def codCleanString(string):
    return string.replace('^0', '').replace('^1', '').replace('^2', '').replace('^3', '').replace('^4', '').replace('^5', '').replace('^6', '').replace('^7', '').replace('^8', '').replace('^9', '').replace('^;', '').replace('^:', '')
def hostname():
        #client.message('^7Hostname: ^2'+ str(b3.parser.Parser._publicIp)) b3 is not ALWAYS hosted where the gameserver is, so the socket server wont either ;3
        #return str( json.load(urllib2.urlopen('http://httpbin.org/ip'))['origin'] ) #alternative is: urllib2.urlopen('http://ip.42.pl/raw').read()
        return urllib2.urlopen('http://v4v6.ipv6-test.com/api/myip.php').read() #but http://v4v6.ipv6-test.com/api/myip.php has ipv6 support....