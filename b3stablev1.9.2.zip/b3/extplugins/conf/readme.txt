
-------------------------------------------------------------------------------
|                    ^1Host-Tech Test Server^7                                               |
|                    ------------                                              |
|^2Basic Commands  ^7                                                              |
|   !h                  - For Commandlist                                      |
|   !h <command>        - Description/syntax of command                        |
|   !register           - Registers in server                                  |
|   !rules              - Displays Basic rules & regulations                   |
|   !toadmin <message>  - Messages Admins /report about players                |
|                          /suggestions/complaints                             |
|   !recorddemo <name>  - Records Gameplay of player to                        |
|                                                                                                             |
|    -User can now change map by voting using vote commands                    |
|    -Available vote commands are !votemap !votegametype                       |
|                         !votekick !voteban !votestatus                       |
|    -New punishment commands are active for admins such as                    |
|                                       !shock  !explode                       |
|    -Regular players with good behaviour will promoted to admin               |
|                                                                              |
|                                                                              |
                                                                           |
|Our Website : ^2host-tech.tk^7                                             |
|                                                                                                                                                             |
:                                                                                  :
:        press '^4shift^7' + '^4~^7'  to see readme                                      :