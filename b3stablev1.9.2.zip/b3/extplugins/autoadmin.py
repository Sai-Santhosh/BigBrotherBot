__version__ = '1.4.1'
import b3
import b3.plugin
import b3.events
from b3 import clients

class AutoadminPlugin(b3.plugin.Plugin):
    _adminPlugin = None
    _pluginactived = 'on'
    _noclevel1 = 3000
    _noclevel2 = 10000
    _noclevel3 = 50000
    _noclevel4 = 1000000
    _nocminlevel = 1
    _adminlevel = 100
    gnamelevel0 = 'User'
    gkeywordlevel0 = 'user'
    gnamelevel = 'Regular'
    gkeywordlevel = 'reg'
    gnamelevel1 = 'Moderator'
    gkeywordlevel1 = 'mod'
    gnamelevel2 = 'Admin'
    gkeywordlevel2 = 'admin'
    gnamelevel3 = 'Full Admin'
    gkeywordlevel3 = 'fulladmin'
    gnamelevel4 = 'SeniorAdmin'
    gkeywordlevel4 = 'senioradmin'

    def onStartup(self):
        self._adminPlugin = self.console.getPlugin('admin')
        self._xlrstatPlugin = self.console.getPlugin('xlrstats')
        if not self._adminPlugin:
            self.error('Could not find admin plugin')
            return False
        if not self._adminPlugin:
            self.error('Could not find xlrstats plugin')
            return False
        self.registerEvent(b3.events.EVT_CLIENT_AUTH)
        self.registerEvent(b3.events.EVT_CLIENT_KILL)
        self._adminPlugin.registerCommand(self, 'nok', self._nocminlevel, self.cmd_nok)
        self._adminPlugin.registerCommand(self, 'autoadmin', self._adminlevel, self.cmd_autoadmin)

    def onLoadConfig(self):
        try:
            self._pluginactived = self.config.get('settings', 'pluginactived')
        except Exception as err:
            self.warning('Using default value %s for AutoAdmin. %s' % (self._pluginactived, err))

        self.debug('Autoreg : %s' % self._pluginactived)
        try:
            self._noclevel1 = self.config.getint('settings', 'noclevel1')
        except Exception as err:
            self.warning('Using default value %s for level 1. %s' % (self._noclevel1, err))

        self.debug('number of kills for level 1 : %s' % self._noclevel1)
        try:
            self._noclevel2 = self.config.getint('settings', 'noclevel2')
        except Exception as err:
            self.warning('Using default value %s for level 2. %s' % (self._noclevel2, err))

        self.debug('number of kills for level 2 : %s' % self._noclevel2)
        try:
            self._noclevel3 = self.config.getint('settings', 'noclevel3')
        except Exception as err:
            self.warning('Using default value %s for level 3. %s' % (self._noclevel3, err))

        self.debug('number of kills for level 3 : %s' % self._noclevel3)
        try:
            self._noclevel4 = self.config.getint('settings', 'noclevel4')
        except Exception as err:
            self.warning('Using default value %s for level 4. %s' % (self._noclevel4, err))

        self.debug('number of kills for level 4 : %s' % self._noclevel4)
        try:
            self._nocminlevel = self.config.getint('settings', 'nocminlevel')
        except Exception as err:
            self.warning('Using default value %s for cmd noc. %s' % (self._nocminlevel, err))

        self.debug('min level for cmd !nok : %s' % self._nocminlevel)
        try:
            self._adminlevel = self.config.getint('settings', 'adminlevel')
        except Exception as err:
            self.warning('Using default value %s for adminlevel. %s' % (self._adminlevel, err))

        self.debug('min level for cmds : %s' % self._adminlevel)

    def onEvent(self, event):
        if self._pluginactived == 'on':
            if event.type == b3.events.EVT_CLIENT_KILL:
                client = event.client
                cgroup = client.maxGroup.name
                stats = self._xlrstatPlugin.get_PlayerStats(client)
                if cgroup == self.gnamelevel0 and stats.kills >= self._noclevel1 and stats.kills <= self._noclevel1 + 5:
                    self.debug('clientmaxLevel : %s cgroup : %s gnamelevel0 : %s' % (client.maxLevel, cgroup, self.gnamelevel0))
                    client.message('You are connected ^2%s^7 times & has ^3%s ^1Kills^7.' % (client.connections, stats.kills))
                    client.message('You are now in the group ^2%s ^7[^220^7]' % self.gnamelevel1)
                    try:
                        group = clients.Group(keyword=self.gkeywordlevel1)
                        group = self.console.storage.getGroup(group)
                    except:
                        return False

                    client.setGroup(group)
                    client.save()
                    self.console.write('scroll "%s has been Promoted as %s" ' % (client.exactName, self.gnamelevel1))
                if cgroup == self.gnamelevel and stats.kills >= self._noclevel1 and stats.kills <= self._noclevel1 + 5:
                    self.debug('clientmaxLevel : %s cgroup : %s gnamelevel0 : %s' % (client.maxLevel, cgroup, self.gnamelevel0))
                    client.message('You are connected ^2%s^7 times & has ^3%s ^1Kills^7.' % (client.connections, stats.kills))
                    client.message('You are now in the group ^2%s ^7[^220^7]' % self.gnamelevel1)
                    try:
                        group = clients.Group(keyword=self.gkeywordlevel1)
                        group = self.console.storage.getGroup(group)
                    except:
                        return False

                    client.setGroup(group)
                    client.save()
                    self.console.write('scroll "%s has been Promoted as %s" ' % (client.exactName, self.gnamelevel1))
                if cgroup == self.gnamelevel1 and stats.kills >= self._noclevel2 and stats.kills <= self._noclevel2 + 5:
                    self.debug('clientmaxLevel : %s cgroup : %s gnamelevel1 : %s' % (client.maxLevel, cgroup, self.gnamelevel1))
                    client.message('You are connected ^2%s^7 times & has ^3%s ^1Kills^7.' % (client.connections, stats.kills))
                    client.message('you are now in the group ^2%s ^7[^240^7]' % self.gnamelevel2)
                    try:
                        group = clients.Group(keyword=self.gkeywordlevel2)
                        group = self.console.storage.getGroup(group)
                    except:
                        return False

                    client.setGroup(group)
                    client.save()
                    self.console.write('scroll "%s has been Promoted as %s" ' % (client.exactName, self.gnamelevel2))
                if cgroup == self.gnamelevel2 and stats.kills >= self._noclevel3 and stats.kills <= self._noclevel3 + 5:
                    self.debug('clientmaxLevel : %s cgroup : %s gnamelevel1 : %s' % (client.maxLevel, cgroup, self.gnamelevel2))
                    client.message('You are connected ^2%s^7 times & has ^3%s ^1Kills^7.' % (client.connections, stats.kills))
                    client.message('you are now in the group ^2%s ^7[^260^7]' % self.gnamelevel3)
                    try:
                        group = clients.Group(keyword=self.gkeywordlevel3)
                        group = self.console.storage.getGroup(group)
                    except:
                        return False

                    client.setGroup(group)
                    client.save()
                    self.console.write('scroll "%s has been Promoted as %s" ' % (client.exactName, self.gnamelevel3))
                if cgroup == self.gnamelevel3 and stats.kills >= self._noclevel4:
                    self.debug('clientmaxLevel : %s cgroup : %s gnamelevel1 : %s' % (client.maxLevel, cgroup, self.gnamelevel3))
                    client.message('You are connected ^2%s^7 times & has ^3%s ^1Kills^7.' % (client.connections, stats.kills))
                    client.message('you are now in the group ^2%s ^7[^280^7]' % self.gnamelevel2)
                    try:
                        group = clients.Group(keyword=self.gkeywordlevel4)
                        group = self.console.storage.getGroup(group)
                    except:
                        return False

                    client.setGroup(group)
                    client.save()
                    self.console.write('scroll "%s has been Promoted as %s "' % (client.exactName, self.gnamelevel4))
        else:
            return False

    def cmd_nok(self, data, client, cmd = None):
        """        info client kills 
        """
        if data:
            input = self._adminPlugin.parseUserCmd(data)
        else:
            remain = 999
            levelup = ' '
            stats = self._xlrstatPlugin.get_PlayerStats(client)
            if client.maskedGroup:
                cgroup = client.maskedGroup.name
                if cgroup == 'User':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Regular':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Moderator':
                    remain = self._noclevel2 - stats.kills
                    levelup = self.gnamelevel2
                elif cgroup == 'Admin':
                    remain = self._noclevel3 - stats.kills
                    levelup = self.gnamelevel3
                elif cgroup == 'Full Admin':
                    remain = self._noclevel4 - stats.kills
                    levelup = self.gnamelevel4
                elif cgroup == 'Senior Admin':
                    client.message('%s^7 now has ^2%s ^1Kills^7:You have Reached the maximum allotted Level.' % (client.exactName, stats.kills))
                    return
                else:
                    client.message('You are not registered: Killstatus Not available')
                    return

            else:
                cgroup = client.maxGroup.name
                if cgroup == 'User':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Regular':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Moderator':
                    remain = self._noclevel2 - stats.kills
                    levelup = self.gnamelevel2
                elif cgroup == 'Admin':
                    remain = self._noclevel3 - stats.kills
                    levelup = self.gnamelevel3
                elif cgroup == 'Full Admin':
                    remain = self._noclevel4 - stats.kills
                    levelup = self.gnamelevel4
                else:
                    if cgroup == 'Senior Admin':
                        client.message('%s^7 now has ^2%s ^1Kills^7: You have Reached the maximum allotted Level.' % (client.exactName, stats.kills))
                        return
                    client.message('You are not registered: Killstatus Not available')
                    return
            if remain < 0:
                client.message('You are demoted. AutoAdmin Disabled for you. Contact SuperAdmin to reset/regain your power')
                return
            client.message('%s^7 now has ^2%s ^1Kills^7:  Requires ^2%s ^1kills^7 to promote as ^2%s^7  ' % (client.exactName,
             stats.kills,
             remain,
             levelup))
            return
        sclient = self._adminPlugin.findClientPrompt(input[0], client)
        if sclient:
            remain = 999
            levelup = ' '
            stats = self._xlrstatPlugin.get_PlayerStats(sclient)
            if sclient.maskedGroup:
                cgroup = sclient.maskedGroup.name
                if cgroup == 'User':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Regular':
                    remain = self._noclevel1 - stats.kills
                elif cgroup == 'Moderator':
                    remain = self._noclevel2 - stats.kills
                    levelup = self.gnamelevel2
                elif cgroup == 'Admin':
                    remain = self._noclevel3 - stats.kills
                    levelup = self.gnamelevel3
                elif cgroup == 'Full Admin':
                    remain = self._noclevel4 - stats.kills
                    levelup = self.gnamelevel4
                elif cgroup == 'Senior Admin':
                    client.message('%s^7 now has ^2%s ^1Kills^7: He Reached the maximum allotted Level.' % (sclient.exactName, stats.kills))
                    return
                else:
                    client.message('He is not registered: Killstatus Not available')
                    return

            else:
                cgroup = sclient.maxGroup.name
                if cgroup == 'User':
                    remain = self._noclevel1 - stats.kills
                    levelup = self.gnamelevel1
                elif cgroup == 'Regular':
                    remain = self._noclevel1 - stats.kills
                elif cgroup == 'Moderator':
                    remain = self._noclevel2 - stats.kills
                    levelup = self.gnamelevel2
                elif cgroup == 'Admin':
                    remain = self._noclevel3 - stats.kills
                    levelup = self.gnamelevel3
                elif cgroup == 'Full Admin':
                    remain = self._noclevel4 - stats.kills
                    levelup = self.gnamelevel4
                else:
                    if cgroup == 'Senior Admin':
                        client.message('%s^7 now has ^2%s ^1Kills^7: He Reached the maximum allotted Level.' % (sclient.exactName, stats.kills))
                        return
                    client.message('He is not registered: Killstatus Not available')
                    return
            if remain < 0:
                client.message('He is demoted. AutoAdmin Disabled for him. Contact SuperAdmin for details.')
                return
            client.message('%s^7 now has ^2%s ^1Kills^7:  Requires ^2%s ^1kills^7 to promote as ^2%s^7  ' % (sclient.exactName,
             stats.kills,
             remain,
             levelup))
        else:
            return False

    def cmd_autoadmin(self, data, client, cmd = None):
        """        activate / deactivate autoadmin or change number of kills
        """
        if data:
            input = self._adminPlugin.parseUserCmd(data)
        else:
            if self._pluginactived == 'on':
                client.message('AutoAdmin is ^2activated^7 ')
            if self._pluginactived == 'off':
                client.message('Autoadmin is ^1deactivated^7 ')
            client.message('The number of kills for ^3Level1 ^7is ^2%s^7 ' % self._noclevel1)
            client.message('The number of kills for ^3Level2 ^7is ^2%s^7 ' % self._noclevel2)
            client.message('The number of kills for ^3Level3 ^7is ^2%s^7 ' % self._noclevel3)
            client.message('The number of kills for ^3Level4 ^7is ^2%s^7 ' % self._noclevel4)
            client.message('!autoadmin <on / off> or <level1 or level2> <number of kills>')
            return False
        if input[0] == 'on':
            if self._pluginactived != 'on':
                self._pluginactived = 'on'
                message = 'AutoAdmin is now ^2activated^7 '
                settingname = 'pluginactived'
                settingsvalue = 'on'
            else:
                client.message('AutoAdmin is already ^2activated')
                return False
        elif input[0] == 'off':
            if self._pluginactived != 'off':
                self._pluginactived = 'off'
                message = 'AutoAdmin ^1deactivated^7 '
                settingname = 'pluginactived'
                settingsvalue = 'off'
            else:
                client.message('autoadmin is already ^1disabled')
                return False
        elif input[0] == 'level1' or input[0] == 'level2':
            if input[1]:
                if input[1].isdigit():
                    if input[0] == 'level1':
                        self._noclevel1 = input[1]
                        settingname = 'noclevel1'
                    if input[0] == 'level2':
                        self._noclevel2 = input[1]
                        settingname = 'noclevel2'
                    if input[0] == 'level3':
                        self._noclevel3 = input[1]
                        settingname = 'noclevel1'
                    if input[0] == 'level4':
                        self._noclevel4 = input[1]
                        settingname = 'noclevel2'
                    settingsvalue = input[1]
                    message = 'The number of kills for ^3%s ^7is now ^2%s^7 ' % (input[0], settingsvalue)
                else:
                    client.message('!autoadmin <level1 or level2> <number of kills>')
                    return False
            else:
                if input[0] == 'level1':
                    client.message('The number of kills for ^3%s ^7is ^2%s^7 ' % (input[0], self._noclevel1))
                if input[0] == 'level2':
                    client.message('The number of kills for ^3%s ^7is ^2%s^7 ' % (input[0], self._noclevel2))
                client.message('!autoadmin <level1 or level2> <number of kills>')
                return False
        else:
            client.message('!autoadmin <on / off> or <level1 or level2> <number of kills>')
            return False
        client.message('%s ' % message)
        modif = '%s: %s\n' % (settingname, settingsvalue)
        fichier = self.config.fileName
        autoregini = open(fichier, 'r')
        contenu = autoregini.readlines()
        autoregini.close()
        newcontenu = ''
        for ligne in contenu:
            if settingname in ligne:
                ligne = modif
            newcontenu = '%s%s' % (newcontenu, ligne)

        autoreginiw = open(fichier, 'w')
        autoreginiw.write(newcontenu)
        autoreginiw.close()

    def group(self):
        self.rgname = None
        self.rgkeyword = None
        cursor = self.console.storage.query('\n        SELECT *\n        FROM groups n \n        ')
        if cursor.EOF:
            cursor.close()
            return False
        else:
            while not cursor.EOF:
                sr = cursor.getRow()
                gname = sr['name']
                gkeyword = sr['keyword']
                glevel = sr['level']
                if glevel == 0:
                    self.gnamelevel0 = gname
                    self.gkeywordlevel0 = gkeyword
                if glevel == 1:
                    self.gnamelevel1 = gname
                    self.gkeywordlevel1 = gkeyword
                if glevel == 2:
                    self.gnamelevel2 = gname
                    self.gkeywordlevel2 = gkeyword
                if glevel == 3:
                    self.gnamelevel0 = gname
                    self.gkeywordlevel0 = gkeyword
                if glevel == 4:
                    self.gnamelevel1 = gname
                    self.gkeywordlevel1 = gkeyword
                if glevel == 5:
                    self.gnamelevel2 = gname
                    self.gkeywordlevel2 = gkeyword
                if glevel == 6:
                    self.gnamelevel2 = gname
                    self.gkeywordlevel2 = gkeyword
                cursor.moveNext()

            cursor.close()
            return