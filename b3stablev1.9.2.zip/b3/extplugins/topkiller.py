# ------------------------------------------------------------------------------------------
#
#
#
#
# ------------------------------------------------------------------------------------------
# CHANGELOG
#    xx/xx/xxxxx - 1.0.0 - Anubis
#    - dunno
#    xx/xx/xxxxx - 1.0.1 - Anubis
#    - dunno as well
#    xx/xx/xxxxx - 1.0.2 - Anubis
#   - Headshots added
#    20/03/2009 - 1.0.3 - Anubis
#    - annoucing 3 top killers instead of 1
#    xx/xx/xxxxx - 1.0.4 - Anubis
#    - ability to name top killers added

__version__ = '1.0.4'
__author__  = 'Anubis'

from b3 import clients
import b3, os, string, re, threading
import b3.events
import b3.plugin


class KillStats:
    count = 0
    damage = int(0)
    client = None
    headshots = 0

#--------------------------------------------------------------------------------------------------
class TopkillerPlugin(b3.plugin.Plugin):

    _clientvar_name = 'topkiller'
    _placemap = {1:'1st ', 2:'2nd ', 3:'3rd '}
    
    def onStartup(self):
        self.registerEvent(b3.events.EVT_CLIENT_KILL)
        self.registerEvent(b3.events.EVT_GAME_ROUND_END)
        self.registerEvent(b3.events.EVT_CLIENT_DAMAGE)
        #self.registerEvent(b3.events.EVT_GAME_ROUND_START) 
        self.registerEvent(b3.events.EVT_CLIENT_DISCONNECT)
        self.registerEvent(b3.events.EVT_GAME_EXIT)

    def onLoadConfig(self):
        self.debug('Loading Configuration Started')
        try:
            self._placemap[1] = self.config.get('settings', 'firstplace')
        except:
            print "No text defined for first place, using -" + self._placemap[1] + "-"

        try:
            self._placemap[2] = self.config.get('settings', 'secondplace')
        except:
            print "No text defined for second place, using -" + self._placemap[2] + "-"

        try:
            self._placemap[3] = self.config.get('settings', 'thirdplace')
        except:
            print "No text defined for third place, using -" + self._placemap[2] + "-"

    def onEvent(self, event):
        try:
            if event.type == b3.events.EVT_CLIENT_KILL:
                self.handle_kills(event)
            elif event.type == b3.events.EVT_CLIENT_DISCONNECT:
                clientbycid = self.console.clients.getByCID(event.data)
                if clientbycid:
                    self.init_kill_stats(clientbycid)
            elif event.type == b3.events.EVT_GAME_ROUND_END or event.type == b3.events.EVT_GAME_EXIT:
                self.debug('Map End: Showing message')
                self.show_message()
                for c in self.console.clients.getList():
                    if(c):
                        self.init_kill_stats(c)
            elif event.type == b3.events.EVT_CLIENT_DAMAGE:
                self.clientDamage(event)
            
        #elif event.type == b3.events.EVT_GAME_ROUND_START:
        #    for c in self.console.clients.getList():
        #        if(c):
        #            self.init_kill_stats(c)
        except:
            self.debug("-==== onEvent ")
        
    def get_kill_stats(self, client):
        if not client.var(self, 'topkiller', 0).value:
            client.setvar(self, 'topkiller', KillStats())

        return client.var(self, 'topkiller', 0).value

    def init_kill_stats(self, client):
        # initialize the clients spree stats
        client.setvar(self, 'topkiller', KillStats())

    def getTopKiller(self):
        topclient = None
        i = 0
        maxdmg = float(0)
        clients = self.console.clients.getList()
        for c in clients:
            try:
                killStats = self.get_kill_stats(c)
                if(killStats):
                    if(killStats.count > 0):
                        if(killStats.count > i):
                            topclient = killStats;
                            i = killStats.count
                            maxdmg = killStats.damage
                        elif(killStats.count == i):
                            if(killStats.damage > maxdmg):
                                topclient = killStats;
                                i = killStats.count
                                maxdmg = killStats.damage


            except:
                self.debug("-==== except getTopKiller ")
                pass
    
        return topclient
        
    def removeTopKiller(self, client):
        client.setvar(self, 'topkiller', KillStats())       
    
    def show_message(self):
        self.console.say('Top Killer(s)!:')
        for inext in range(1,4):
            killStats = self.getTopKiller()
            if killStats:
                if killStats.client:
                    clientName = '^1'
                    if self._placemap.has_key(inext):
                        clientName += self._placemap[inext] + ' '
                    else:
                        clientName += str(inext) + self.getsuffix(inext) + '. '
                    
                    clientName += '^2%s^7 '% killStats.client.exactName

                    self.console.say('%s^3 with ^2%s^3 kills and damage: ^2%s ! ^3Headshots: ^2%s !'%(clientName,killStats.count, killStats.damage, killStats.headshots))
                    self.removeTopKiller(killStats.client)


    def getsuffix(self, index):
        if(index == 1):
          return 'st'
        if(index == 2):
          return 'nd'
        if(index == 3):
          return 'rd'
        if(index > 3):
          return 'th'
            
    def clientDamage(self, event):
        """\
        A damage was made. 
        """
        client = event.client
    
        if client:
            damage = int(event.data[0])
            #weapon = event.data[1]
            #hitlocation = event.data[2]
            
            kstats = self.get_kill_stats(client)
            if kstats:
                kstats.damage += int(damage)
                if not kstats.client:
                    kstats.client = client
            
                self.debug("Damage: " + client.name + " count: " + str(kstats.count) + " damage: " + str(damage) + " total damage: " + str(kstats.damage) + "")                        
                
    def handle_kills(self, event):
        """\
        A kill was made. 
        """
        client = event.client
    
        if client:
            damage = int(event.data[0])
            
            #weapon = event.data[1]
            #hitlocation = event.data[2]
            #self.clientKill(event.client, event.target, int(event.data[0]))

            kstats = self.get_kill_stats(client)
            if kstats:
                kstats.damage += int(damage)
                kstats.count += 1
                
                if not kstats.client:
                    kstats.client = client
                
                if event.data[3] == 'MOD_HEAD_SHOT':
                    kstats.headshots += 1 
            
                self.debug("Kill: " + client.name + " count: " + str(kstats.count) + " damage: " + str(damage) + " total damage: " + str(kstats.damage) + " headshots:" + str(kstats.headshots))
    
    
 
 
 
 
 
 
 
 
 
 