__version__ = '1.0'
__author__  = 'Spoon'

import b3, re, traceback, sys, threading
import b3.events
import b3.plugin
from b3 import functions
#--------------------------------------------------------------------------------------------------
class WebsitePlugin(b3.plugin.Plugin):
    _adminPlugin = None

    def onStartup(self):  
        self._adminPlugin = self.console.getPlugin('admin')  
        if not self._adminPlugin:  
            return False  
        #SET COMMAND LEVEL HERE 
        self.registerEvent(b3.events.EVT_CLIENT_SAY) 
        self.registerEvent(b3.events.EVT_CLIENT_TEAM_SAY)

    def onLoadConfig(self):
        self.debug('getting config now')
        try:
            self._maxLevel = self.config.getint('settings', 'max_level')
        except:
            self.error('config missing [settings].maxlevel')
        try:
            self._duration = self.config.get('settings', 'duration')
        except:
            self.error('config missing [settings].duration')
        try:
            self._message = self.config.get('settings', 'message')
        except:
            self.error('config missing [settings].message')

    def check_for_website(self, client, text):
        originalword = text
        text = text.replace('.co.uk', '')
        text = text.replace('.com', '')
        text = text.replace('.org', '')
        text = text.replace('.net', '')
        text = text.replace('.info', '')
        text = text.replace('.biz', '')
        text = text.replace('.me.uk', '')
        text = text.replace('.de', '')
        text = text.replace('.tk', '')
        text = text.replace('.jp', '')
        text = text.replace('.es', '')
        text = text.replace('.dk', '')
        text = text.replace('.fr', '')
        if (text == originalword):
            return False
        else:
            self.said_website( client, text)

    def said_website(self, client, text):
        originalword = text
        text = text.replace('bigbrotherbot', '')
        text = text.replace('ehdgaming', '')
        text = text.replace('cod4zombies', '')
        text = text.replace('codzombies', '')
        text = text.replace('google', '')
        text = text.replace('youtube', '')
        text = text.replace('pbbans', '')
        text = text.replace('inx-gaming', '')
        text = text.replace('bashandslash', '')
        text = text.replace('evenbalance', '')
        text = text.replace('ehdfiles', '')
        if (text != originalword):
            return False
        else:
            message = self._message
            duration = self._duration
            keyword = 'None'
            client.tempban(message, keyword, duration, client)
            #self._adminPlugin.tempbanClient(client, self._message, None, False, '', self._duration)

    def onEvent(self, event):
        if not event.client or event.client.maxLevel >= self._maxLevel:
            return
        if event.type == b3.events.EVT_CLIENT_SAY or event.type == b3.events.EVT_CLIENT_TEAM_SAY:
            self.check_for_website(event.client,event.data)

