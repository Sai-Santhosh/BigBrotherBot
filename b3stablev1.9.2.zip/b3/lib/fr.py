#!/usr/bin/python
# -*- coding: iso-8859-1 -*-


import os, sys

class Parser():


        def function(self, pays, region, city):
                CPFind = 0
                DepFind = 0
                departement = ''
                # We find the path of the file and add b3/lib
                pathname = os.getcwd() + '/b3/lib/'

                # if country = France we read fr.txt to find postal code and departement number
                if pays == 'FR' and city != '':
                        try:
                                inputville = file("%sfr.txt" %(pathname), "r")
                        except:
                                print('File not found %s'% (inputville))
                               
                        inputville.seek(0)
                        while CPFind == 0:
                                LigneVille = inputville.readline()
                                try:
                                        if LigneVille != '':
                                                # We split the line
                                                TableauVille = LigneVille.split(',')
                                                # [0] is the Region Code
                                                # [1] is the postal code
                                                # [2] is the city name
                                                RegionVille = TableauVille[0]
                                                Ville = TableauVille[2]

                                                # City found in the good region
                                                if city in Ville and RegionVille == region:
                                                        # We extract departement code
                                                        CP = TableauVille[1]
                                                        # We takes the 2 first char of postal code string
                                                        DepExtrCP = CP[0:2]
                                                        # We get departement name
                                                        if DepExtrCP == '01':
                                                                departement = 'Ain'
                                                        elif DepExtrCP == '02':
                                                                departement = 'Aisne'
                                                        elif DepExtrCP == '03':
                                                                departement = 'Allier'
                                                        elif DepExtrCP == '04':
                                                                departement = 'Alpes de Haute Provence'
                                                        elif DepExtrCP == '05':
                                                                departement = 'Hautes Alpes'
                                                        elif DepExtrCP == '06':
                                                                departement = 'Alpes Maritimes'
                                                        elif DepExtrCP == '07':
                                                                departement = 'Ardeche'
                                                        elif DepExtrCP == '08':
                                                                departement = 'Ardennes'
                                                        elif DepExtrCP == '09':
                                                                departement = 'Ariege'
                                                        elif DepExtrCP == '10':
                                                                departement = 'Aube'
                                                        elif DepExtrCP == '11':
                                                                departement = 'Aude'
                                                        elif DepExtrCP == '12':
                                                                departement = 'Aveyron'
                                                        elif DepExtrCP == '13':
                                                                departement = 'Bouches du Rhone'
                                                        elif DepExtrCP == '14':
                                                                departement = 'Calvados'
                                                        elif DepExtrCP == '15':
                                                                departement = 'Cantal'
                                                        elif DepExtrCP == '16':
                                                                departement = 'Charente'
                                                        elif DepExtrCP == '17':
                                                                departement = 'Charente Maritime'
                                                        elif DepExtrCP == '18':
                                                                departement = 'Cher'
                                                        elif DepExtrCP == '19':
                                                                departement = 'Correze'
                                                        elif DepExtrCP == '20':
                                                                departement = 'Corse'
                                                        elif DepExtrCP == '21':
                                                                departement = "Cote-d'Or"
                                                        elif DepExtrCP == '22':
                                                                departement = "Cotes d'armor"
                                                        elif DepExtrCP == '23':
                                                                departement = 'Creuse'
                                                        elif DepExtrCP == '24':
                                                                departement = 'Dordogne'
                                                        elif DepExtrCP == '25':
                                                                departement = 'Doubs'
                                                        elif DepExtrCP == '26':
                                                                departement = 'Drome'
                                                        elif DepExtrCP == '27':
                                                                departement = 'Eure'
                                                        elif DepExtrCP == '28':
                                                                departement = 'Eure et Loir'
                                                        elif DepExtrCP == '29':
                                                                departement = 'Finistere'
                                                        elif DepExtrCP == '30':
                                                                departement = 'Gard'
                                                        elif DepExtrCP == '31':
                                                                departement = 'Haute Garonne'
                                                        elif DepExtrCP == '32':
                                                                departement = 'Gers'
                                                        elif DepExtrCP == '33':
                                                                departement = 'Gironde'
                                                        elif DepExtrCP == '34':
                                                                departement = 'Herault'
                                                        elif DepExtrCP == '35':
                                                                departement = 'Ile et Vilaine'
                                                        elif DepExtrCP == '36':
                                                                departement = 'Indre'
                                                        elif DepExtrCP == '37':
                                                                departement = 'Indre et Loire'
                                                        elif DepExtrCP == '38':
                                                                departement = 'Isere'
                                                        elif DepExtrCP == '39':
                                                                departement = 'Jura'
                                                        elif DepExtrCP == '40':
                                                                departement = 'Landes'
                                                        elif DepExtrCP == '41':
                                                                departement = 'Loir et Cher'
                                                        elif DepExtrCP == '42':
                                                                departement = 'Loire'
                                                        elif DepExtrCP == '43':
                                                                departement = 'Haute Loire'
                                                        elif DepExtrCP == '44':
                                                                departement = 'Loire Atlantique'
                                                        elif DepExtrCP == '45':
                                                                departement = 'Loiret'
                                                        elif DepExtrCP == '46':
                                                                departement = 'Lot'
                                                        elif DepExtrCP == '47':
                                                                departement = 'Lot et Garonne'
                                                        elif DepExtrCP == '48':
                                                                departement = 'Lozere'
                                                        elif DepExtrCP == '49':
                                                                departement = 'Maine et Loire'
                                                        elif DepExtrCP == '50':
                                                                departement = 'Manche'
                                                        elif DepExtrCP == '51':
                                                                departement = 'Marne'
                                                        elif DepExtrCP == '52':
                                                                departement = 'Haute Marne'
                                                        elif DepExtrCP == '53':
                                                                departement = 'Mayenne'
                                                        elif DepExtrCP == '54':
                                                                departement = 'Meurthe et Moselle'
                                                        elif DepExtrCP == '55':
                                                                departement = 'Meuse'
                                                        elif DepExtrCP == '56':
                                                                departement = 'Morbihan'
                                                        elif DepExtrCP == '57':
                                                                departement = 'Moselle'
                                                        elif DepExtrCP == '58':
                                                                departement = 'Nievre'
                                                        elif DepExtrCP == '59':
                                                                departement = 'Nord'
                                                        elif DepExtrCP == '60':
                                                                departement = 'Oise'
                                                        elif DepExtrCP == '61':
                                                                departement = 'Orne'
                                                        elif DepExtrCP == '62':
                                                                departement = 'Pas de Calais'
                                                        elif DepExtrCP == '63':
                                                                departement = 'Puy de Dome'
                                                        elif DepExtrCP == '64':
                                                                departement = 'Pyrenees Atlantiques'
                                                        elif DepExtrCP == '65':
                                                                departement = 'Hautes Pyrenees'
                                                        elif DepExtrCP == '66':
                                                                departement = 'Pyrenees Orientales'
                                                        elif DepExtrCP == '67':
                                                                departement = 'Bas Rhin'
                                                        elif DepExtrCP == '68':
                                                                departement = 'Haut Rhin'
                                                        elif DepExtrCP == '69':
                                                                departement = 'Rhone'
                                                        elif DepExtrCP == '70':
                                                                departement = 'Haute Saone'
                                                        elif DepExtrCP == '71':
                                                                departement = 'Saone et Loire'
                                                        elif DepExtrCP == '72':
                                                                departement = 'Sarthe'
                                                        elif DepExtrCP == '73':
                                                                departement = 'Savoie'
                                                        elif DepExtrCP == '74':
                                                                departement = 'Haute Savoie'
                                                        elif DepExtrCP == '75':
                                                                departement = 'Paris'
                                                        elif DepExtrCP == '76':
                                                                departement = 'Seine Maritime'
                                                        elif DepExtrCP == '77':
                                                                departement = 'Seine et Marne'
                                                        elif DepExtrCP == '78':
                                                                departement = 'Yvelines'
                                                        elif DepExtrCP == '79':
                                                                departement = 'Deux Sevres'
                                                        elif DepExtrCP == '80':
                                                                departement = 'Somme'
                                                        elif DepExtrCP == '81':
                                                                departement = 'Tarn'
                                                        elif DepExtrCP == '82':
                                                                departement = 'Tarn et Garonne'
                                                        elif DepExtrCP == '83':
                                                                departement = 'Var'
                                                        elif DepExtrCP == '84':
                                                                departement = 'Vaucluse'
                                                        elif DepExtrCP == '85':
                                                                departement = 'Vendee'
                                                        elif DepExtrCP == '86':
                                                                departement = 'Vienne'
                                                        elif DepExtrCP == '87':
                                                                departement = 'Haute Vienne'
                                                        elif DepExtrCP == '88':
                                                                departement = 'Vosges'
                                                        elif DepExtrCP == '89':
                                                                departement = 'Yonne'
                                                        elif DepExtrCP == '90':
                                                                departement = 'Territoire de Belfort'
                                                        elif DepExtrCP == '91':
                                                                departement = 'Essonne'
                                                        elif DepExtrCP == '92':
                                                                departement = 'Hauts de Seine'
                                                        elif DepExtrCP == '93':
                                                                departement = 'Seine Saint Denis'
                                                        elif DepExtrCP == '94':
                                                                departement = 'Val de Marne'
                                                        elif DepExtrCP == '95':
                                                                departement = "Val d'oise"
                                                        CPFind = 1
                                        elif LigneVille == '':
                                                # City not found
                                                CPFind = 1
                                                departement = ''
                                                        
                                except:
                                        print('Lect CP Pb avec ligne: %s'% (LigneVille))




                # We add departement name to city name
                if departement != '':
                        city = city + ' ' + departement

                # We return to localise player plugin
                return city


