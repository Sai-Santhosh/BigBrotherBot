[![BigBrotherBot](http://www.bigbrotherbot.net/sites/default/files/b3-logo-light-text.png)](http://www.bigbrotherbot.net/)

This folder contains plugin and parser examples which can be used by 3rd party developers to create their own
plugin and parsers. They illustrate basic functionalities and some basic interaction with the B3 core. If you need
more advanced examples, please submit a new issue on this very repository.