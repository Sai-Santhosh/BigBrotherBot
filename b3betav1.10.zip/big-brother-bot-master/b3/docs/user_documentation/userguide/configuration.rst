.. _guide-config:

=============
Configuration
=============

.. _config-basic:

Basics
------

.. _config-messages:

Messages
--------

