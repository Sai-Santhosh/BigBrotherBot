.. _guide-intro:

============
Introduction
============

This user guide describes some of the concepts of B3.
Detailed instructions and configuration options can be found in the documentation of the plugins.

