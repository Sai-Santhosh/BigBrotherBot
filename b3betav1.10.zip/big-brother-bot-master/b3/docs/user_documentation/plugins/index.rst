.. index:: Plugins

Plugins
=======

B3 in itself does not do much. Features like in-game commands or automated tasks really come from plugins.
However there one special plugin, the admin plugin, which is at the heart of B3 and which allows other plugins to add their own commands.


Contents:

.. toctree::
   :maxdepth: 2

   admin
   adv
   censor
   status
   teamkill
   stats
   login
   welcome
   spamcontrol
   pingwatch
   punkbuster