.. index:: Plugins; TeamKill, TeamKill plugin
.. _plugin-tk:

TeamKill
========
