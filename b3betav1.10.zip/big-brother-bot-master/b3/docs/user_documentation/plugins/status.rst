.. index:: Plugins; Status, Status plugin
.. _plugin-status:

Status
======
