.. index:: Plugins; Login, Login plugin
.. _plugin-login:

Login
=====
