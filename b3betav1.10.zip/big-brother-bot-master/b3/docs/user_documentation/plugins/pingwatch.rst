.. index:: Plugins; PingWatch, PingWatch plugin
.. _plugin-pingwatch:

PingWatch
=========
