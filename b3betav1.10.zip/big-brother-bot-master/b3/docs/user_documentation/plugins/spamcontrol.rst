.. index:: Plugins; SpamControl, SpamControl plugin
.. _plugin-spam:

SpamControl
===========
