.. index:: Plugins; Adv, Adv plugin
.. _plugin-adv:

Advertisement
=============
