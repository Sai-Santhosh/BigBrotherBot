.. index:: Plugins; Censor, Censor plugin
.. _plugin-censor:

Censor
======
