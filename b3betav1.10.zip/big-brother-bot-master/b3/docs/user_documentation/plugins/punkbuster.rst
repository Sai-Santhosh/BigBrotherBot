.. index:: Plugins; PunkBuster, PunkBuster plugin
.. _plugin-pb:

Punkbuster
==========
