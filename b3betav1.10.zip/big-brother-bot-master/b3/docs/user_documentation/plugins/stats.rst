.. index:: Plugins; Stats, Stats plugin
.. _plugin-stats:

Stats
=====

