Getting Started
===============

.. toctree::
    :maxdepth: 2

    install
    game_configuration
    first_run