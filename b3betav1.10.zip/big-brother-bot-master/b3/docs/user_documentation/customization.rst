Customizing
===========

- Advanced configuration
- How to install 3rd party plugins