"""The RunSnakeRun GUI Profiler utility"""
__version__ = '2.0.0b6'
