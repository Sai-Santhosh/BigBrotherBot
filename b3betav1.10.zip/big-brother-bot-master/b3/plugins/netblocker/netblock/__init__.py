# Allow us to import this directory as a module and get, well, the
# module. This is a sleazy hack and probably morally wrong, but it's
# oh so convenient.
# TODO: do this better.
from b3.plugins.netblocker.netblock.netblock import *
