IPBan Plugin for Big Brother Bot
================================

### Description

This plugin checks the IP addresses of clients with an active ban or tempban. So in addition to the GUID check, it also
checks the IP address belonging to the client with the active (temp)ban and kicks if appropriate.